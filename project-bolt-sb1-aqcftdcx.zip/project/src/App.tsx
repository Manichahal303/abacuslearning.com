import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import Sidebar from './components/Sidebar';
import HomePage from './components/HomePage';
import LessonsPage from './components/LessonsPage';
import PracticePage from './components/PracticePage';
import FreeModeSection from './components/FreeModeSection';
import RollNoPage from './components/RollNoPage';
import AchievementsPage from './components/AchievementsPage';
import ProfilePage from './components/ProfilePage';

export interface UserData {
  rollNo: string;
  name: string;
  email: string;
  joinDate: string;
  lastActive: string;
  totalLessons: number;
  completedLessons: number;
  practiceProblems: number;
  mathProblems: number;
  achievements: number;
  totalTime: number;
  accuracy: number;
  currentStreak: number;
  bestStreak: number;
  level: number;
  points: number;
  rank: number;
  recentActivity: Array<{
    date: string;
    activity: string;
    score?: number;
    time?: number;
  }>;
  progressData: {
    lessons: Array<{ week: string; completed: number }>;
    practice: Array<{ week: string; problems: number }>;
    accuracy: Array<{ week: string; percentage: number }>;
  };
}

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);
  const [isSignedIn, setIsSignedIn] = useState(false);

  // Load user data from localStorage on app start
  useEffect(() => {
    const savedUser = localStorage.getItem('abacuslearn_user');
    if (savedUser) {
      const userData = JSON.parse(savedUser);
      setCurrentUser(userData);
      setIsSignedIn(true);
    }
  }, []);

  // Save user data to localStorage whenever it changes
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('abacuslearn_user', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  const handleSignIn = (userData: UserData) => {
    setCurrentUser(userData);
    setIsSignedIn(true);
    localStorage.setItem('abacuslearn_user', JSON.stringify(userData));
  };

  const handleSignOut = () => {
    setCurrentUser(null);
    setIsSignedIn(false);
    localStorage.removeItem('abacuslearn_user');
    setActiveTab('home');
  };

  const updateUserProgress = (updates: Partial<UserData>) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, ...updates };
      setCurrentUser(updatedUser);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage onNavigate={setActiveTab} currentUser={currentUser} />;
      case 'lessons':
        return <LessonsPage onNavigate={setActiveTab} currentUser={currentUser} onUpdateProgress={updateUserProgress} />;
      case 'practice':
        return <PracticePage onNavigate={setActiveTab} currentUser={currentUser} onUpdateProgress={updateUserProgress} />;
      case 'freemode':
        return <FreeModeSection onNavigate={setActiveTab} currentUser={currentUser} onUpdateProgress={updateUserProgress} />;
      case 'rollno':
        return <RollNoPage onNavigate={setActiveTab} onSignIn={handleSignIn} currentUser={currentUser} />;
      case 'achievements':
        return <AchievementsPage onNavigate={setActiveTab} currentUser={currentUser} />;
      case 'profile':
        return <ProfilePage onNavigate={setActiveTab} currentUser={currentUser} onUpdateProgress={updateUserProgress} />;
      default:
        return <HomePage onNavigate={setActiveTab} currentUser={currentUser} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      {isSignedIn && currentUser && (
        <Sidebar 
          currentUser={currentUser} 
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onSignOut={handleSignOut}
        />
      )}
      
      {/* Main Content */}
      <div className={`flex-1 ${isSignedIn ? 'ml-0' : ''}`}>
        <Navigation 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
          currentUser={currentUser}
          isSignedIn={isSignedIn}
        />
        <main>
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;