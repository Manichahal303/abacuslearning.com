import React from 'react';
import { 
  Home, 
  BookOpen, 
  Calculator, 
  Zap, 
  Trophy, 
  User, 
  LogOut, 
  TrendingUp,
  Star,
  Clock,
  Target
} from 'lucide-react';
import { UserData } from '../App';

interface SidebarProps {
  currentUser: UserData;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onSignOut: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentUser, activeTab, onTabChange, onSignOut }) => {
  const navigationItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'freemode', label: 'Free Mode', icon: Zap },
    { id: 'lessons', label: 'Lessons', icon: BookOpen },
    { id: 'practice', label: 'Practice', icon: Calculator },
    { id: 'achievements', label: 'Achievements', icon: Trophy },
    { id: 'profile', label: 'My Profile', icon: User },
  ];

  const formatTime = (ms: number) => {
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="w-80 bg-white shadow-xl border-r border-gray-200 h-screen overflow-y-auto">
      {/* User Profile Section */}
      <div className="p-6 bg-gradient-to-br from-blue-600 to-purple-600 text-white">
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center text-white font-bold text-xl">
            {currentUser.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold">{currentUser.name}</h3>
            <p className="text-blue-100 font-semibold">Roll No: {currentUser.rollNo}</p>
            <p className="text-blue-200 text-sm">Level {currentUser.level} • Rank #{currentUser.rank}</p>
          </div>
        </div>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white bg-opacity-10 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold">{currentUser.points}</div>
            <div className="text-xs text-blue-100">Points</div>
          </div>
          <div className="bg-white bg-opacity-10 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold">{currentUser.accuracy}%</div>
            <div className="text-xs text-blue-100">Accuracy</div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="p-4">
        <nav className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === item.id
                    ? item.id === 'freemode'
                      ? 'bg-purple-100 text-purple-700 border border-purple-200'
                      : 'bg-blue-100 text-blue-700 border border-blue-200'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Progress Overview */}
      <div className="p-4 border-t border-gray-200">
        <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
          <TrendingUp className="w-4 h-4 mr-2" />
          Quick Overview
        </h4>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-gray-600">Lessons</span>
            </div>
            <span className="text-sm font-semibold">{currentUser.completedLessons}/{currentUser.totalLessons}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Calculator className="w-4 h-4 text-green-600" />
              <span className="text-sm text-gray-600">Problems</span>
            </div>
            <span className="text-sm font-semibold">{currentUser.practiceProblems + currentUser.mathProblems}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Trophy className="w-4 h-4 text-purple-600" />
              <span className="text-sm text-gray-600">Achievements</span>
            </div>
            <span className="text-sm font-semibold">{currentUser.achievements}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-orange-600" />
              <span className="text-sm text-gray-600">Study Time</span>
            </div>
            <span className="text-sm font-semibold">{formatTime(currentUser.totalTime)}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-yellow-600" />
              <span className="text-sm text-gray-600">Streak</span>
            </div>
            <span className="text-sm font-semibold">{currentUser.currentStreak} days</span>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="p-4 border-t border-gray-200">
        <h4 className="font-semibold text-gray-900 mb-3">Recent Activity</h4>
        <div className="space-y-2 max-h-32 overflow-y-auto">
          {currentUser.recentActivity.slice(0, 3).map((activity, index) => (
            <div key={index} className="text-xs text-gray-600 bg-gray-50 rounded p-2">
              <div className="font-medium">{activity.activity}</div>
              <div className="text-gray-500">{new Date(activity.date).toLocaleDateString()}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Sign Out */}
      <div className="p-4 border-t border-gray-200">
        <button
          onClick={onSignOut}
          className="w-full flex items-center space-x-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;