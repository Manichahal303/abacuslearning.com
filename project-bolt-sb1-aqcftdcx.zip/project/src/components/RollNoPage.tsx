import React, { useState, useEffect } from 'react';
import { UserCheck, Search, Trophy, TrendingUp, Calendar, Clock, Target, Star, Award, BookOpen, Calculator, Zap, Users, BarChart3, PieChart, Activity, CheckCircle } from 'lucide-react';
import { UserData } from '../App';

interface RollNoPageProps {
  onNavigate: (tab: string) => void;
  onSignIn: (userData: UserData) => void;
  currentUser: UserData | null;
}

const RollNoPage: React.FC<RollNoPageProps> = ({ onNavigate, onSignIn, currentUser }) => {
  const [searchRollNo, setSearchRollNo] = useState('');
  const [showSignIn, setShowSignIn] = useState(false);
  const [signInData, setSignInData] = useState({ name: '', email: '' });
  const [searchedUser, setSearchedUser] = useState<UserData | null>(null);
  const [searchError, setSearchError] = useState('');

  // Mock database of users
  const [users, setUsers] = useState<UserData[]>([
    {
      rollNo: 'AB001',
      name: 'Priya Sharma',
      email: 'priya.sharma@email.com',
      joinDate: '2024-01-15',
      lastActive: '2024-01-20',
      totalLessons: 6,
      completedLessons: 4,
      practiceProblems: 250,
      mathProblems: 180,
      achievements: 8,
      totalTime: 1200000,
      accuracy: 87,
      currentStreak: 5,
      bestStreak: 12,
      level: 8,
      points: 1250,
      rank: 15,
      recentActivity: [
        { date: '2024-01-20', activity: 'Completed Level 7 Math Practice', score: 92, time: 15 },
        { date: '2024-01-19', activity: 'Finished Lesson 4: Traditional vs Free Mode', time: 25 },
        { date: '2024-01-18', activity: 'Practiced Abacus - Hard Mode', score: 85, time: 12 },
        { date: '2024-01-17', activity: 'Earned Achievement: Quick Learner', time: 8 }
      ],
      progressData: {
        lessons: [
          { week: 'Week 1', completed: 2 },
          { week: 'Week 2', completed: 1 },
          { week: 'Week 3', completed: 1 },
          { week: 'Week 4', completed: 0 }
        ],
        practice: [
          { week: 'Week 1', problems: 50 },
          { week: 'Week 2', problems: 75 },
          { week: 'Week 3', problems: 80 },
          { week: 'Week 4', problems: 45 }
        ],
        accuracy: [
          { week: 'Week 1', percentage: 75 },
          { week: 'Week 2', percentage: 82 },
          { week: 'Week 3', percentage: 85 },
          { week: 'Week 4', percentage: 87 }
        ]
      }
    },
    {
      rollNo: 'AB002',
      name: 'Rajesh Kumar',
      email: 'rajesh.kumar@email.com',
      joinDate: '2024-01-10',
      lastActive: '2024-01-20',
      totalLessons: 6,
      completedLessons: 6,
      practiceProblems: 420,
      mathProblems: 350,
      achievements: 12,
      totalTime: 1800000,
      accuracy: 94,
      currentStreak: 8,
      bestStreak: 15,
      level: 12,
      points: 2100,
      rank: 8,
      recentActivity: [
        { date: '2024-01-20', activity: 'Completed Level 12 Math Practice', score: 98, time: 18 },
        { date: '2024-01-19', activity: 'Mastered All Lessons', time: 30 },
        { date: '2024-01-18', activity: 'Practiced Free Mode Advanced', score: 95, time: 20 },
        { date: '2024-01-17', activity: 'Earned Achievement: Abacus Master', time: 5 }
      ],
      progressData: {
        lessons: [
          { week: 'Week 1', completed: 3 },
          { week: 'Week 2', completed: 2 },
          { week: 'Week 3', completed: 1 },
          { week: 'Week 4', completed: 0 }
        ],
        practice: [
          { week: 'Week 1', problems: 80 },
          { week: 'Week 2', problems: 120 },
          { week: 'Week 3', problems: 110 },
          { week: 'Week 4', problems: 110 }
        ],
        accuracy: [
          { week: 'Week 1', percentage: 85 },
          { week: 'Week 2', percentage: 90 },
          { week: 'Week 3', percentage: 92 },
          { week: 'Week 4', percentage: 94 }
        ]
      }
    },
    {
      rollNo: 'AB003',
      name: 'Anita Patel',
      email: 'anita.patel@email.com',
      joinDate: '2024-01-12',
      lastActive: '2024-01-20',
      totalLessons: 6,
      completedLessons: 3,
      practiceProblems: 180,
      mathProblems: 120,
      achievements: 6,
      totalTime: 900000,
      accuracy: 82,
      currentStreak: 3,
      bestStreak: 8,
      level: 6,
      points: 850,
      rank: 25,
      recentActivity: [
        { date: '2024-01-20', activity: 'Completed Level 6 Math Practice', score: 88, time: 22 },
        { date: '2024-01-19', activity: 'Finished Lesson 3: Working with Place Values', time: 25 },
        { date: '2024-01-18', activity: 'Practiced Abacus - Medium Mode', score: 80, time: 15 },
        { date: '2024-01-17', activity: 'Earned Achievement: Practice Makes Perfect', time: 10 }
      ],
      progressData: {
        lessons: [
          { week: 'Week 1', completed: 1 },
          { week: 'Week 2', completed: 1 },
          { week: 'Week 3', completed: 1 },
          { week: 'Week 4', completed: 0 }
        ],
        practice: [
          { week: 'Week 1', problems: 30 },
          { week: 'Week 2', problems: 45 },
          { week: 'Week 3', problems: 55 },
          { week: 'Week 4', problems: 50 }
        ],
        accuracy: [
          { week: 'Week 1', percentage: 70 },
          { week: 'Week 2', percentage: 75 },
          { week: 'Week 3', percentage: 80 },
          { week: 'Week 4', percentage: 82 }
        ]
      }
    }
  ]);

  const generateRollNo = () => {
    const lastRollNo = users.length > 0 ? Math.max(...users.map(u => parseInt(u.rollNo.substring(2)))) : 0;
    return `AB${String(lastRollNo + 1).padStart(3, '0')}`;
  };

  const handleSignIn = () => {
    if (!signInData.name || !signInData.email) return;

    const newRollNo = generateRollNo();
    const newUser: UserData = {
      rollNo: newRollNo,
      name: signInData.name,
      email: signInData.email,
      joinDate: new Date().toISOString().split('T')[0],
      lastActive: new Date().toISOString().split('T')[0],
      totalLessons: 6,
      completedLessons: 0,
      practiceProblems: 0,
      mathProblems: 0,
      achievements: 0,
      totalTime: 0,
      accuracy: 0,
      currentStreak: 0,
      bestStreak: 0,
      level: 1,
      points: 0,
      rank: users.length + 1,
      recentActivity: [
        { date: new Date().toISOString().split('T')[0], activity: 'Joined AbacusLearn Platform', time: 0 }
      ],
      progressData: {
        lessons: [
          { week: 'Week 1', completed: 0 },
          { week: 'Week 2', completed: 0 },
          { week: 'Week 3', completed: 0 },
          { week: 'Week 4', completed: 0 }
        ],
        practice: [
          { week: 'Week 1', problems: 0 },
          { week: 'Week 2', problems: 0 },
          { week: 'Week 3', problems: 0 },
          { week: 'Week 4', problems: 0 }
        ],
        accuracy: [
          { week: 'Week 1', percentage: 0 },
          { week: 'Week 2', percentage: 0 },
          { week: 'Week 3', percentage: 0 },
          { week: 'Week 4', percentage: 0 }
        ]
      }
    };

    setUsers(prev => [...prev, newUser]);
    onSignIn(newUser);
    setShowSignIn(false);
    setSignInData({ name: '', email: '' });
  };

  const handleSearch = () => {
    const user = users.find(u => u.rollNo.toLowerCase() === searchRollNo.toLowerCase());
    if (user) {
      setSearchedUser(user);
      setSearchError('');
    } else {
      setSearchedUser(null);
      setSearchError('Roll number not found. Please check and try again.');
    }
  };

  const formatTime = (ms: number) => {
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    return `${hours}h ${minutes}m`;
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const UserReport: React.FC<{ user: UserData; isOwn?: boolean }> = ({ user, isOwn = false }) => (
    <div className="bg-white rounded-2xl shadow-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
            {user.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{user.name}</h2>
            <p className="text-gray-600">Roll No: <span className="font-semibold text-green-600">{user.rollNo}</span></p>
            <p className="text-sm text-gray-500">Joined: {formatDate(user.joinDate)}</p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-blue-600">#{user.rank}</div>
          <div className="text-gray-600">Global Rank</div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg text-center">
          <BookOpen className="w-8 h-8 text-blue-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-blue-600">{user.completedLessons}/{user.totalLessons}</div>
          <div className="text-sm text-gray-600">Lessons</div>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg text-center">
          <Calculator className="w-8 h-8 text-green-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-green-600">{user.practiceProblems + user.mathProblems}</div>
          <div className="text-sm text-gray-600">Problems Solved</div>
        </div>
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg text-center">
          <Trophy className="w-8 h-8 text-purple-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-purple-600">{user.achievements}</div>
          <div className="text-sm text-gray-600">Achievements</div>
        </div>
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-4 rounded-lg text-center">
          <Target className="w-8 h-8 text-orange-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-orange-600">{user.accuracy}%</div>
          <div className="text-sm text-gray-600">Accuracy</div>
        </div>
      </div>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <BarChart3 className="w-6 h-6 mr-2 text-blue-600" />
            Performance Metrics
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Current Level:</span>
              <span className="font-semibold text-blue-600">Level {user.level}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Points:</span>
              <span className="font-semibold text-green-600">{user.points.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Current Streak:</span>
              <span className="font-semibold text-orange-600">{user.currentStreak} days</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Best Streak:</span>
              <span className="font-semibold text-purple-600">{user.bestStreak} days</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Study Time:</span>
              <span className="font-semibold text-gray-900">{formatTime(user.totalTime)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Last Active:</span>
              <span className="font-semibold text-gray-900">{formatDate(user.lastActive)}</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <Activity className="w-6 h-6 mr-2 text-green-600" />
            Recent Activity
          </h3>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {user.recentActivity.map((activity, index) => (
              <div key={index} className="bg-white rounded-lg p-3 border border-gray-200">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{activity.activity}</p>
                    <p className="text-xs text-gray-500">{formatDate(activity.date)}</p>
                  </div>
                  <div className="text-right">
                    {activity.score && (
                      <div className="text-sm font-semibold text-green-600">{activity.score}%</div>
                    )}
                    {activity.time && (
                      <div className="text-xs text-gray-500">{activity.time}min</div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Progress Charts */}
      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
          <TrendingUp className="w-6 h-6 mr-2 text-purple-600" />
          Weekly Progress
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-3">Lessons Completed</h4>
            <div className="space-y-2">
              {user.progressData.lessons.map((week, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{week.week}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${(week.completed / 2) * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-semibold">{week.completed}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-3">Practice Problems</h4>
            <div className="space-y-2">
              {user.progressData.practice.map((week, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{week.week}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-600 h-2 rounded-full"
                        style={{ width: `${Math.min((week.problems / 100) * 100, 100)}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-semibold">{week.problems}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-3">Accuracy Trend</h4>
            <div className="space-y-2">
              {user.progressData.accuracy.map((week, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{week.week}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-purple-600 h-2 rounded-full"
                        style={{ width: `${week.percentage}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-semibold">{week.percentage}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {isOwn && (
        <div className="mt-8 flex justify-center space-x-4">
          <button
            onClick={() => onNavigate('lessons')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
          >
            Continue Learning
          </button>
          <button
            onClick={() => onNavigate('practice')}
            className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold"
          >
            Practice More
          </button>
        </div>
      )}
    </div>
  );

  // If user is already signed in, show their report
  if (currentUser && !searchedUser) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center">
            <UserCheck className="w-10 h-10 mr-3 text-green-600" />
            My Progress Report
          </h1>
          <p className="text-xl text-gray-600">
            Your personal learning dashboard and progress tracking
          </p>
        </div>

        <UserReport user={currentUser} isOwn={true} />

        {/* Search Other Students */}
        <div className="mt-12 bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <Search className="w-6 h-6 mr-2 text-purple-600" />
            Find Other Students
          </h2>
          
          <div className="max-w-md mx-auto">
            <div className="space-y-4">
              <div>
                <input
                  type="text"
                  value={searchRollNo}
                  onChange={(e) => setSearchRollNo(e.target.value.toUpperCase())}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 text-center font-mono text-lg"
                  placeholder="Enter Roll Number (e.g., AB001)"
                />
              </div>
              
              {searchError && (
                <div className="text-red-600 text-sm text-center">{searchError}</div>
              )}
              
              <button
                onClick={handleSearch}
                disabled={!searchRollNo}
                className="w-full px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold"
              >
                Search Report
              </button>
            </div>
            
            <div className="mt-6 text-sm text-gray-500 text-center">
              <p className="mb-2">Sample Roll Numbers to try:</p>
              <div className="flex justify-center space-x-4">
                <button
                  onClick={() => setSearchRollNo('AB001')}
                  className="px-3 py-1 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors font-mono"
                >
                  AB001
                </button>
                <button
                  onClick={() => setSearchRollNo('AB002')}
                  className="px-3 py-1 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors font-mono"
                >
                  AB002
                </button>
                <button
                  onClick={() => setSearchRollNo('AB003')}
                  className="px-3 py-1 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors font-mono"
                >
                  AB003
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center">
          <UserCheck className="w-10 h-10 mr-3 text-green-600" />
          Roll Number System
        </h1>
        <p className="text-xl text-gray-600">
          Get your unique roll number and track your learning progress
        </p>
      </div>

      {!currentUser && !searchedUser && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Sign In Section */}
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <Users className="w-6 h-6 mr-2 text-blue-600" />
              Get Your Roll Number
            </h2>
            
            {!showSignIn ? (
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-green-600 rounded-full flex items-center justify-center mb-6 mx-auto">
                  <UserCheck className="w-10 h-10 text-white" />
                </div>
                <p className="text-gray-600 mb-6">
                  Join our learning community and get a unique roll number to track your progress, 
                  compete with others, and showcase your achievements!
                </p>
                <button
                  onClick={() => setShowSignIn(true)}
                  className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold text-lg"
                >
                  Sign Up Now
                </button>
                <div className="mt-4 text-sm text-gray-500">
                  Free registration • Instant roll number • Progress tracking
                </div>
              </div>
            ) : (
              <div>
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                    <input
                      type="text"
                      value={signInData.name}
                      onChange={(e) => setSignInData(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <input
                      type="email"
                      value={signInData.email}
                      onChange={(e) => setSignInData(prev => ({ ...prev, email: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter your email"
                    />
                  </div>
                </div>
                
                <div className="flex space-x-4">
                  <button
                    onClick={handleSignIn}
                    disabled={!signInData.name || !signInData.email}
                    className="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold"
                  >
                    Get My Roll Number
                  </button>
                  <button
                    onClick={() => setShowSignIn(false)}
                    className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-semibold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Search Section */}
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <Search className="w-6 h-6 mr-2 text-purple-600" />
              Find Student Report
            </h2>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center mb-6 mx-auto">
                <Search className="w-10 h-10 text-white" />
              </div>
              <p className="text-gray-600 mb-6">
                Enter any student's roll number to view their progress report, achievements, 
                and learning statistics.
              </p>
              
              <div className="space-y-4">
                <div>
                  <input
                    type="text"
                    value={searchRollNo}
                    onChange={(e) => setSearchRollNo(e.target.value.toUpperCase())}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 text-center font-mono text-lg"
                    placeholder="Enter Roll Number (e.g., AB001)"
                  />
                </div>
                
                {searchError && (
                  <div className="text-red-600 text-sm">{searchError}</div>
                )}
                
                <button
                  onClick={handleSearch}
                  disabled={!searchRollNo}
                  className="w-full px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold"
                >
                  Search Report
                </button>
              </div>
              
              <div className="mt-6 text-sm text-gray-500">
                <p className="mb-2">Sample Roll Numbers to try:</p>
                <div className="flex justify-center space-x-4">
                  <button
                    onClick={() => setSearchRollNo('AB001')}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors font-mono"
                  >
                    AB001
                  </button>
                  <button
                    onClick={() => setSearchRollNo('AB002')}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors font-mono"
                  >
                    AB002
                  </button>
                  <button
                    onClick={() => setSearchRollNo('AB003')}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors font-mono"
                  >
                    AB003
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* User Report Display */}
      {searchedUser && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Student Report</h2>
            <button
              onClick={() => {
                setSearchedUser(null);
                setSearchRollNo('');
                setSearchError('');
              }}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              Search Another
            </button>
          </div>
          <UserReport user={searchedUser} />
        </div>
      )}

      {/* Features Section */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-8">
        <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">Roll Number System Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <UserCheck className="w-8 h-8 text-blue-600 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-900 mb-2">Unique Identity</h3>
            <p className="text-gray-600 text-sm">
              Get your personal roll number for easy identification and progress tracking.
            </p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <BarChart3 className="w-8 h-8 text-green-600 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-900 mb-2">Progress Reports</h3>
            <p className="text-gray-600 text-sm">
              Detailed analytics of your learning journey with charts and statistics.
            </p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <Trophy className="w-8 h-8 text-purple-600 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-900 mb-2">Global Rankings</h3>
            <p className="text-gray-600 text-sm">
              See how you rank among all students and compete for the top positions.
            </p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm text-center">
            <Search className="w-8 h-8 text-orange-600 mx-auto mb-3" />
            <h3 className="font-semibold text-gray-900 mb-2">Public Reports</h3>
            <p className="text-gray-600 text-sm">
              Anyone can view progress reports by entering a roll number for transparency.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RollNoPage;