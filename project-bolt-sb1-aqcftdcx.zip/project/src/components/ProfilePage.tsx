import React, { useState } from 'react';
import { 
  User, 
  Edit3, 
  Save, 
  X, 
  Trophy, 
  Target, 
  Clock, 
  Star, 
  TrendingUp, 
  Calendar,
  Mail,
  Award,
  BarChart3,
  Activity
} from 'lucide-react';
import { UserData } from '../App';

interface ProfilePageProps {
  onNavigate: (tab: string) => void;
  currentUser: UserData | null;
  onUpdateProgress: (updates: Partial<UserData>) => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate, currentUser, onUpdateProgress }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || ''
  });

  if (!currentUser) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
          <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Please Sign In</h2>
          <p className="text-gray-600 mb-6">You need to sign in to view your profile.</p>
          <button
            onClick={() => onNavigate('rollno')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
          >
            Sign In / Get Roll Number
          </button>
        </div>
      </div>
    );
  }

  const handleSave = () => {
    onUpdateProgress({
      name: editData.name,
      email: editData.email
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData({
      name: currentUser.name,
      email: currentUser.email
    });
    setIsEditing(false);
  };

  const formatTime = (ms: number) => {
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    return `${hours}h ${minutes}m`;
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const completionPercentage = Math.round((currentUser.completedLessons / currentUser.totalLessons) * 100);

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center">
          <User className="w-10 h-10 mr-3 text-blue-600" />
          My Profile
        </h1>
        <p className="text-xl text-gray-600">
          Manage your account and track your learning progress
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Profile Information */}
        <div className="xl:col-span-1">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Profile Info</h2>
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Edit3 className="w-5 h-5" />
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={handleSave}
                    className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                  >
                    <Save className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleCancel}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>

            <div className="text-center mb-6">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-2xl mx-auto mb-4">
                {currentUser.name.split(' ').map(n => n[0]).join('')}
              </div>
              <div className="text-3xl font-bold text-green-600 mb-1">{currentUser.rollNo}</div>
              <div className="text-sm text-gray-500">Roll Number</div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                {isEditing ? (
                  <input
                    type="text"
                    value={editData.name}
                    onChange={(e) => setEditData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                ) : (
                  <div className="px-3 py-2 bg-gray-50 rounded-lg text-gray-900">{currentUser.name}</div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                {isEditing ? (
                  <input
                    type="email"
                    value={editData.email}
                    onChange={(e) => setEditData(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                ) : (
                  <div className="px-3 py-2 bg-gray-50 rounded-lg text-gray-900 flex items-center">
                    <Mail className="w-4 h-4 mr-2 text-gray-500" />
                    {currentUser.email}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Join Date</label>
                <div className="px-3 py-2 bg-gray-50 rounded-lg text-gray-900 flex items-center">
                  <Calendar className="w-4 h-4 mr-2 text-gray-500" />
                  {formatDate(currentUser.joinDate)}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Last Active</label>
                <div className="px-3 py-2 bg-gray-50 rounded-lg text-gray-900 flex items-center">
                  <Activity className="w-4 h-4 mr-2 text-gray-500" />
                  {formatDate(currentUser.lastActive)}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl shadow-xl p-6 mt-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button
                onClick={() => onNavigate('lessons')}
                className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
              >
                Continue Learning
              </button>
              <button
                onClick={() => onNavigate('practice')}
                className="w-full px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold"
              >
                Practice Problems
              </button>
              <button
                onClick={() => onNavigate('achievements')}
                className="w-full px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-semibold"
              >
                View Achievements
              </button>
            </div>
          </div>
        </div>

        {/* Statistics and Progress */}
        <div className="xl:col-span-2 space-y-8">
          {/* Performance Overview */}
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <BarChart3 className="w-6 h-6 mr-2 text-blue-600" />
              Performance Overview
            </h2>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-3 mx-auto">
                  <Trophy className="w-8 h-8 text-blue-600" />
                </div>
                <div className="text-2xl font-bold text-blue-600">#{currentUser.rank}</div>
                <div className="text-sm text-gray-600">Global Rank</div>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-3 mx-auto">
                  <Target className="w-8 h-8 text-green-600" />
                </div>
                <div className="text-2xl font-bold text-green-600">{currentUser.accuracy}%</div>
                <div className="text-sm text-gray-600">Accuracy</div>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-3 mx-auto">
                  <Star className="w-8 h-8 text-purple-600" />
                </div>
                <div className="text-2xl font-bold text-purple-600">{currentUser.points}</div>
                <div className="text-sm text-gray-600">Total Points</div>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-3 mx-auto">
                  <Clock className="w-8 h-8 text-orange-600" />
                </div>
                <div className="text-2xl font-bold text-orange-600">{formatTime(currentUser.totalTime)}</div>
                <div className="text-sm text-gray-600">Study Time</div>
              </div>
            </div>

            {/* Progress Bars */}
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">Lesson Progress</span>
                  <span className="text-sm text-gray-500">{currentUser.completedLessons}/{currentUser.totalLessons}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-blue-600 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${completionPercentage}%` }}
                  ></div>
                </div>
                <div className="text-right text-xs text-gray-500 mt-1">{completionPercentage}% Complete</div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">Current Streak</span>
                  <span className="text-sm text-gray-500">{currentUser.currentStreak} days</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-orange-600 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min((currentUser.currentStreak / currentUser.bestStreak) * 100, 100)}%` }}
                  ></div>
                </div>
                <div className="text-right text-xs text-gray-500 mt-1">Best: {currentUser.bestStreak} days</div>
              </div>
            </div>
          </div>

          {/* Detailed Statistics */}
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <TrendingUp className="w-6 h-6 mr-2 text-green-600" />
              Detailed Statistics
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Learning Progress</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Completed Lessons:</span>
                    <span className="font-semibold">{currentUser.completedLessons}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Practice Problems:</span>
                    <span className="font-semibold">{currentUser.practiceProblems}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Math Problems:</span>
                    <span className="font-semibold">{currentUser.mathProblems}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Problems:</span>
                    <span className="font-semibold">{currentUser.practiceProblems + currentUser.mathProblems}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Current Level:</span>
                    <span className="font-semibold">Level {currentUser.level}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Achievements</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Achievements:</span>
                    <span className="font-semibold">{currentUser.achievements}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Best Streak:</span>
                    <span className="font-semibold">{currentUser.bestStreak} days</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Current Streak:</span>
                    <span className="font-semibold">{currentUser.currentStreak} days</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Overall Accuracy:</span>
                    <span className="font-semibold">{currentUser.accuracy}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Study Time:</span>
                    <span className="font-semibold">{formatTime(currentUser.totalTime)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <Activity className="w-6 h-6 mr-2 text-purple-600" />
              Recent Activity
            </h2>

            <div className="space-y-4">
              {currentUser.recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Award className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{activity.activity}</p>
                      <p className="text-sm text-gray-500">{formatDate(activity.date)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {activity.score && (
                      <div className="text-lg font-semibold text-green-600">{activity.score}%</div>
                    )}
                    {activity.time && (
                      <div className="text-sm text-gray-500">{activity.time} min</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;