import React, { useState, useEffect } from 'react';
import { ArrowLeft, Trophy, Target, Clock, Star, TrendingUp, CheckCircle, XCircle, Plus, Minus, X, Divide, Calculator } from 'lucide-react';
import FreeAbacus from './FreeAbacus';

interface MathPracticeModeProps {
  onBack: () => void;
}

interface Problem {
  id: number;
  num1: number;
  num2: number;
  operation: '+' | '-' | '*' | '/';
  answer: number;
  userAnswer?: number;
  correct?: boolean;
  timeSpent?: number;
}

interface LevelConfig {
  level: number;
  name: string;
  description: string;
  ranges: {
    addition: { min: number; max: number };
    subtraction: { min: number; max: number };
    multiplication: { min: number; max: number };
    division: { min: number; max: number };
  };
}

const MathPracticeMode: React.FC<MathPracticeModeProps> = ({ onBack }) => {
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  const [selectedOperation, setSelectedOperation] = useState<'+' | '-' | '*' | '/' | null>(null);
  const [selectedSet, setSelectedSet] = useState<number | null>(null);
  const [currentProblemIndex, setCurrentProblemIndex] = useState(0);
  const [problems, setProblems] = useState<Problem[]>([]);
  const [userAnswer, setUserAnswer] = useState('');
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [sessionStartTime, setSessionStartTime] = useState(Date.now());
  const [problemStartTime, setProblemStartTime] = useState(Date.now());
  const [completedSets, setCompletedSets] = useState<{[key: string]: boolean}>({});
  const [abacusValue, setAbacusValue] = useState<number>(0);
  const [showAbacus, setShowAbacus] = useState(true);

  const levels: LevelConfig[] = [
    { level: 1, name: "Beginner", description: "Single digit numbers", ranges: { addition: {min: 1, max: 9}, subtraction: {min: 1, max: 9}, multiplication: {min: 1, max: 5}, division: {min: 1, max: 25} }},
    { level: 2, name: "Easy Plus", description: "Numbers up to 15", ranges: { addition: {min: 1, max: 15}, subtraction: {min: 1, max: 15}, multiplication: {min: 1, max: 6}, division: {min: 1, max: 36} }},
    { level: 3, name: "Basic", description: "Numbers up to 25", ranges: { addition: {min: 5, max: 25}, subtraction: {min: 5, max: 25}, multiplication: {min: 2, max: 7}, division: {min: 1, max: 49} }},
    { level: 4, name: "Elementary", description: "Numbers up to 50", ranges: { addition: {min: 10, max: 50}, subtraction: {min: 10, max: 50}, multiplication: {min: 2, max: 8}, division: {min: 1, max: 64} }},
    { level: 5, name: "Primary", description: "Numbers up to 75", ranges: { addition: {min: 15, max: 75}, subtraction: {min: 15, max: 75}, multiplication: {min: 3, max: 9}, division: {min: 1, max: 81} }},
    { level: 6, name: "Intermediate", description: "Numbers up to 100", ranges: { addition: {min: 20, max: 100}, subtraction: {min: 20, max: 100}, multiplication: {min: 3, max: 10}, division: {min: 1, max: 100} }},
    { level: 7, name: "Standard", description: "Numbers up to 150", ranges: { addition: {min: 25, max: 150}, subtraction: {min: 25, max: 150}, multiplication: {min: 4, max: 11}, division: {min: 1, max: 121} }},
    { level: 8, name: "Advanced", description: "Numbers up to 200", ranges: { addition: {min: 50, max: 200}, subtraction: {min: 50, max: 200}, multiplication: {min: 5, max: 12}, division: {min: 1, max: 144} }},
    { level: 9, name: "Expert", description: "Numbers up to 300", ranges: { addition: {min: 75, max: 300}, subtraction: {min: 75, max: 300}, multiplication: {min: 6, max: 13}, division: {min: 1, max: 169} }},
    { level: 10, name: "Master", description: "Numbers up to 500", ranges: { addition: {min: 100, max: 500}, subtraction: {min: 100, max: 500}, multiplication: {min: 7, max: 15}, division: {min: 1, max: 225} }},
    { level: 11, name: "Professional", description: "Numbers up to 750", ranges: { addition: {min: 150, max: 750}, subtraction: {min: 150, max: 750}, multiplication: {min: 8, max: 17}, division: {min: 1, max: 289} }},
    { level: 12, name: "Elite", description: "Numbers up to 1000", ranges: { addition: {min: 200, max: 1000}, subtraction: {min: 200, max: 1000}, multiplication: {min: 10, max: 20}, division: {min: 1, max: 400} }},
    { level: 13, name: "Champion", description: "Numbers up to 1500", ranges: { addition: {min: 300, max: 1500}, subtraction: {min: 300, max: 1500}, multiplication: {min: 12, max: 25}, division: {min: 1, max: 625} }},
    { level: 14, name: "Genius", description: "Numbers up to 2000", ranges: { addition: {min: 500, max: 2000}, subtraction: {min: 500, max: 2000}, multiplication: {min: 15, max: 30}, division: {min: 1, max: 900} }},
    { level: 15, name: "Legendary", description: "Numbers up to 3000", ranges: { addition: {min: 750, max: 3000}, subtraction: {min: 750, max: 3000}, multiplication: {min: 20, max: 35}, division: {min: 1, max: 1225} }},
    { level: 16, name: "Mythical", description: "Numbers up to 5000", ranges: { addition: {min: 1000, max: 5000}, subtraction: {min: 1000, max: 5000}, multiplication: {min: 25, max: 40}, division: {min: 1, max: 1600} }},
    { level: 17, name: "Cosmic", description: "Numbers up to 7500", ranges: { addition: {min: 1500, max: 7500}, subtraction: {min: 1500, max: 7500}, multiplication: {min: 30, max: 50}, division: {min: 1, max: 2500} }},
    { level: 18, name: "Infinite", description: "Numbers up to 10000", ranges: { addition: {min: 2000, max: 10000}, subtraction: {min: 2000, max: 10000}, multiplication: {min: 40, max: 60}, division: {min: 1, max: 3600} }},
    { level: 19, name: "Ultimate", description: "Numbers up to 15000", ranges: { addition: {min: 3000, max: 15000}, subtraction: {min: 3000, max: 15000}, multiplication: {min: 50, max: 75}, division: {min: 1, max: 5625} }},
    { level: 20, name: "Supreme", description: "Numbers up to 20000", ranges: { addition: {min: 5000, max: 20000}, subtraction: {min: 5000, max: 20000}, multiplication: {min: 60, max: 100}, division: {min: 1, max: 10000} }}
  ];

  const operations = [
    { symbol: '+' as const, name: 'Addition', icon: Plus, color: 'bg-green-500' },
    { symbol: '-' as const, name: 'Subtraction', icon: Minus, color: 'bg-blue-500' },
    { symbol: '*' as const, name: 'Multiplication', icon: X, color: 'bg-purple-500' },
    { symbol: '/' as const, name: 'Division', icon: Divide, color: 'bg-orange-500' }
  ];

  const generateProblems = (level: number, operation: '+' | '-' | '*' | '/', setNumber: number): Problem[] => {
    const levelConfig = levels[level - 1];
    const range = levelConfig.ranges[operation === '+' ? 'addition' : operation === '-' ? 'subtraction' : operation === '*' ? 'multiplication' : 'division'];
    const problems: Problem[] = [];

    for (let i = 0; i < 50; i++) {
      let num1: number, num2: number, answer: number;

      switch (operation) {
        case '+':
          num1 = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min;
          num2 = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min;
          answer = num1 + num2;
          break;
        case '-':
          num1 = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min;
          num2 = Math.floor(Math.random() * (num1 - range.min + 1)) + range.min;
          answer = num1 - num2;
          break;
        case '*':
          num1 = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min;
          num2 = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min;
          answer = num1 * num2;
          break;
        case '/':
          answer = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min;
          num2 = Math.floor(Math.random() * 10) + 1;
          num1 = answer * num2;
          break;
        default:
          num1 = 1;
          num2 = 1;
          answer = 2;
      }

      problems.push({
        id: i + 1,
        num1,
        num2,
        operation,
        answer
      });
    }

    return problems;
  };

  const startSet = (level: number, operation: '+' | '-' | '*' | '/', setNumber: number) => {
    const newProblems = generateProblems(level, operation, setNumber);
    setProblems(newProblems);
    setCurrentProblemIndex(0);
    setScore(0);
    setUserAnswer('');
    setShowResult(false);
    setSessionStartTime(Date.now());
    setProblemStartTime(Date.now());
    setSelectedLevel(level);
    setSelectedOperation(operation);
    setSelectedSet(setNumber);
    setAbacusValue(0);
  };

  const handleSubmit = () => {
    const currentProblem = problems[currentProblemIndex];
    const timeSpent = Date.now() - problemStartTime;
    const isCorrect = parseInt(userAnswer) === currentProblem.answer;

    const updatedProblems = [...problems];
    updatedProblems[currentProblemIndex] = {
      ...currentProblem,
      userAnswer: parseInt(userAnswer),
      correct: isCorrect,
      timeSpent
    };
    setProblems(updatedProblems);

    if (isCorrect) {
      setScore(prev => prev + 1);
    }

    setShowResult(true);
    setTimeout(() => {
      if (currentProblemIndex < problems.length - 1) {
        setCurrentProblemIndex(prev => prev + 1);
        setUserAnswer('');
        setShowResult(false);
        setProblemStartTime(Date.now());
        setAbacusValue(0); // Reset abacus for next problem
      } else {
        // Set completed
        const setKey = `${selectedLevel}-${selectedOperation}-${selectedSet}`;
        setCompletedSets(prev => ({ ...prev, [setKey]: true }));
      }
    }, 1500);
  };

  const useAbacusValue = () => {
    setUserAnswer(abacusValue.toString());
  };

  const resetToLevelSelection = () => {
    setSelectedLevel(null);
    setSelectedOperation(null);
    setSelectedSet(null);
    setProblems([]);
    setCurrentProblemIndex(0);
    setScore(0);
    setUserAnswer('');
    setShowResult(false);
    setAbacusValue(0);
  };

  const resetToOperationSelection = () => {
    setSelectedOperation(null);
    setSelectedSet(null);
    setProblems([]);
    setCurrentProblemIndex(0);
    setScore(0);
    setUserAnswer('');
    setShowResult(false);
    setAbacusValue(0);
  };

  const resetToSetSelection = () => {
    setSelectedSet(null);
    setProblems([]);
    setCurrentProblemIndex(0);
    setScore(0);
    setUserAnswer('');
    setShowResult(false);
    setAbacusValue(0);
  };

  // Level Selection View
  if (selectedLevel === null) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-6">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Practice Options</span>
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Math Practice Levels</h2>
            <p className="text-xl text-gray-600">
              Choose your level to practice addition, subtraction, multiplication, and division
            </p>
            <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-center text-blue-800">
                <Calculator className="w-5 h-5 mr-2" />
                <span className="font-semibold">Interactive abacus included for calculation assistance!</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {levels.map((level) => (
              <div
                key={level.level}
                onClick={() => setSelectedLevel(level.level)}
                className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border-2 border-blue-200"
              >
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mb-4 mx-auto">
                    <span className="text-white font-bold text-lg">{level.level}</span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{level.name}</h3>
                  <p className="text-gray-600 text-sm mb-4">{level.description}</p>
                  <div className="bg-blue-100 text-blue-800 py-2 px-4 rounded-lg font-semibold text-sm">
                    4 Operations • 200 Problems
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Operation Selection View
  if (selectedOperation === null) {
    const currentLevel = levels[selectedLevel - 1];
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-6">
          <button
            onClick={resetToLevelSelection}
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Levels</span>
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Level {selectedLevel}: {currentLevel.name}</h2>
            <p className="text-xl text-gray-600 mb-4">{currentLevel.description}</p>
            <p className="text-lg text-gray-500">Choose an operation to practice</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {operations.map((op) => {
              const Icon = op.icon;
              return (
                <div
                  key={op.symbol}
                  onClick={() => setSelectedOperation(op.symbol)}
                  className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border-2 border-gray-200"
                >
                  <div className="text-center">
                    <div className={`w-16 h-16 ${op.color} rounded-2xl flex items-center justify-center mb-4 mx-auto`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{op.name}</h3>
                    <p className="text-gray-600 text-sm mb-4">4 sets of 50 problems each</p>
                    <div className="bg-gray-100 text-gray-800 py-2 px-4 rounded-lg font-semibold text-sm">
                      200 Problems Total
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Set Selection View
  if (selectedSet === null) {
    const currentLevel = levels[selectedLevel - 1];
    const currentOperation = operations.find(op => op.symbol === selectedOperation)!;
    
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-6">
          <button
            onClick={resetToOperationSelection}
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Operations</span>
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              Level {selectedLevel}: {currentOperation.name}
            </h2>
            <p className="text-xl text-gray-600 mb-4">{currentLevel.description}</p>
            <p className="text-lg text-gray-500">Choose a set to practice (50 problems each)</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((setNum) => {
              const setKey = `${selectedLevel}-${selectedOperation}-${setNum}`;
              const isCompleted = completedSets[setKey];
              
              return (
                <div
                  key={setNum}
                  onClick={() => startSet(selectedLevel, selectedOperation, setNum)}
                  className={`bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border-2 ${
                    isCompleted ? 'border-green-300 bg-green-50' : 'border-gray-200'
                  }`}
                >
                  <div className="text-center">
                    <div className={`w-16 h-16 ${isCompleted ? 'bg-green-500' : currentOperation.color} rounded-2xl flex items-center justify-center mb-4 mx-auto`}>
                      {isCompleted ? (
                        <CheckCircle className="w-8 h-8 text-white" />
                      ) : (
                        <span className="text-white font-bold text-xl">{setNum}</span>
                      )}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Set {setNum}</h3>
                    <p className="text-gray-600 text-sm mb-4">50 {currentOperation.name.toLowerCase()} problems</p>
                    <div className={`py-2 px-4 rounded-lg font-semibold text-sm ${
                      isCompleted 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {isCompleted ? 'Completed ✓' : 'Start Practice'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Practice View
  const currentProblem = problems[currentProblemIndex];
  const progress = ((currentProblemIndex + 1) / problems.length) * 100;
  const accuracy = currentProblemIndex > 0 ? Math.round((score / (currentProblemIndex + 1)) * 100) : 0;
  const isCompleted = currentProblemIndex >= problems.length - 1 && showResult;

  if (isCompleted) {
    const totalTime = Date.now() - sessionStartTime;
    const averageTime = problems.reduce((sum, p) => sum + (p.timeSpent || 0), 0) / problems.length;
    const finalAccuracy = Math.round((score / problems.length) * 100);

    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Set Complete!</h2>
            <p className="text-xl text-gray-600">
              Level {selectedLevel} • {operations.find(op => op.symbol === selectedOperation)?.name} • Set {selectedSet}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-green-50 p-6 rounded-lg text-center">
              <Target className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-green-600">{score}/50</div>
              <div className="text-gray-600">Correct Answers</div>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg text-center">
              <Star className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-blue-600">{finalAccuracy}%</div>
              <div className="text-gray-600">Accuracy</div>
            </div>
            <div className="bg-purple-50 p-6 rounded-lg text-center">
              <Clock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-purple-600">{(averageTime / 1000).toFixed(1)}s</div>
              <div className="text-gray-600">Avg. Time</div>
            </div>
          </div>

          <div className="flex justify-center space-x-4">
            <button
              onClick={resetToSetSelection}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
            >
              Choose Another Set
            </button>
            <button
              onClick={() => startSet(selectedLevel, selectedOperation, selectedSet)}
              className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-semibold"
            >
              Retry This Set
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-6">
        <button
          onClick={resetToSetSelection}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Sets</span>
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {/* Problem Section */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                Level {selectedLevel} • {operations.find(op => op.symbol === selectedOperation)?.name} • Set {selectedSet}
              </h2>
              <p className="text-gray-600">Problem {currentProblemIndex + 1} of 50</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">{score}/{currentProblemIndex + 1}</div>
              <div className="text-gray-600">Correct</div>
            </div>
          </div>

          <div className="mb-6">
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>

          {currentProblem && (
            <div className="text-center mb-8">
              <div className="text-5xl font-bold text-gray-900 mb-6">
                {currentProblem.num1} {currentProblem.operation} {currentProblem.num2} = ?
              </div>
              
              <div className="flex flex-col items-center space-y-4">
                <input
                  type="number"
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && userAnswer && handleSubmit()}
                  className="text-3xl font-bold text-center border-2 border-gray-300 rounded-lg p-4 w-64 focus:border-blue-500 focus:outline-none"
                  placeholder="Your answer"
                  disabled={showResult}
                  autoFocus
                />
                
                {abacusValue !== 0 && (
                  <button
                    onClick={useAbacusValue}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-semibold text-sm flex items-center space-x-2"
                  >
                    <Calculator className="w-4 h-4" />
                    <span>Use Abacus Value ({abacusValue})</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {showResult && currentProblem && (
            <div className={`text-center p-6 rounded-lg mb-6 ${
              currentProblem.correct
                ? 'bg-green-100 text-green-800 border-2 border-green-300' 
                : 'bg-red-100 text-red-800 border-2 border-red-300'
            }`}>
              <div className="flex items-center justify-center mb-2">
                {currentProblem.correct ? (
                  <CheckCircle className="w-8 h-8 mr-2" />
                ) : (
                  <XCircle className="w-8 h-8 mr-2" />
                )}
                <span className="text-xl font-bold">
                  {currentProblem.correct ? 'Correct!' : `Incorrect. The answer is ${currentProblem.answer}`}
                </span>
              </div>
            </div>
          )}

          <div className="flex justify-center">
            <button
              onClick={handleSubmit}
              disabled={!userAnswer || showResult}
              className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold text-lg"
            >
              Submit Answer
            </button>
          </div>
        </div>

        {/* Abacus Section */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900 flex items-center">
              <Calculator className="w-6 h-6 mr-2 text-purple-600" />
              Practice Abacus
            </h3>
            <button
              onClick={() => setShowAbacus(!showAbacus)}
              className="px-3 py-1 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
            >
              {showAbacus ? 'Hide' : 'Show'}
            </button>
          </div>

          {showAbacus && (
            <div>
              <div className="mb-4 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <h4 className="font-semibold text-purple-900 mb-2">💡 How to Use</h4>
                <ul className="text-purple-800 text-sm space-y-1">
                  <li>• Use the abacus to help calculate the answer</li>
                  <li>• Set numbers by clicking the beads</li>
                  <li>• The current value shows at the top</li>
                  <li>• Click "Use Abacus Value" to transfer to answer</li>
                  <li>• Reset between problems for fresh calculations</li>
                </ul>
              </div>

              <FreeAbacus
                showValue={true}
                onValueChange={setAbacusValue}
                className="mb-4"
              />

              <div className="text-center text-sm text-gray-600">
                Current Abacus Value: <span className="font-bold text-purple-600">{abacusValue}</span>
              </div>
            </div>
          )}

          {!showAbacus && (
            <div className="text-center py-12 text-gray-500">
              <Calculator className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Abacus is hidden. Click "Show" to use it for calculations.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MathPracticeMode;