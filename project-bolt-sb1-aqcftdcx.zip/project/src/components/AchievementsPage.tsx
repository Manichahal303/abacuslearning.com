import React from 'react';
import { Trophy, Star, Target, Zap, Award, Medal } from 'lucide-react';

interface AchievementsPageProps {
  onNavigate: (tab: string) => void;
}

const AchievementsPage: React.FC<AchievementsPageProps> = ({ onNavigate }) => {
  const achievements = [
    {
      id: 1,
      title: 'First Steps',
      description: 'Complete your first lesson',
      icon: Star,
      earned: true,
      rarity: 'common',
      points: 10
    },
    {
      id: 2,
      title: 'Quick Learner',
      description: 'Complete 5 lessons in a row',
      icon: Zap,
      earned: false,
      rarity: 'uncommon',
      points: 25
    },
    {
      id: 3,
      title: 'Practice Makes Perfect',
      description: 'Score 100% accuracy in practice mode',
      icon: Target,
      earned: true,
      rarity: 'rare',
      points: 50
    },
    {
      id: 4,
      title: 'Speed Demon',
      description: 'Complete 10 problems in under 2 minutes',
      icon: Zap,
      earned: false,
      rarity: 'epic',
      points: 100
    },
    {
      id: 5,
      title: 'Abacus Master',
      description: 'Complete all lessons with perfect scores',
      icon: Trophy,
      earned: false,
      rarity: 'legendary',
      points: 500
    },
    {
      id: 6,
      title: 'Consistent Learner',
      description: 'Practice for 7 days in a row',
      icon: Medal,
      earned: false,
      rarity: 'rare',
      points: 75
    }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'uncommon': return 'bg-green-100 text-green-800 border-green-300';
      case 'rare': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'epic': return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'legendary': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getIconColor = (rarity: string, earned: boolean) => {
    if (!earned) return 'text-gray-400';
    
    switch (rarity) {
      case 'common': return 'text-gray-600';
      case 'uncommon': return 'text-green-600';
      case 'rare': return 'text-blue-600';
      case 'epic': return 'text-purple-600';
      case 'legendary': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  const totalPoints = achievements.filter(a => a.earned).reduce((sum, a) => sum + a.points, 0);
  const earnedCount = achievements.filter(a => a.earned).length;

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Achievements</h1>
        <p className="text-xl text-gray-600">
          Track your progress and unlock rewards as you master the abacus
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold">{earnedCount}</div>
              <div className="text-blue-100">Achievements Earned</div>
            </div>
            <Award className="w-12 h-12 text-blue-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold">{totalPoints}</div>
              <div className="text-green-100">Total Points</div>
            </div>
            <Star className="w-12 h-12 text-green-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold">{Math.round((earnedCount / achievements.length) * 100)}%</div>
              <div className="text-purple-100">Completion Rate</div>
            </div>
            <Trophy className="w-12 h-12 text-purple-200" />
          </div>
        </div>
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((achievement) => {
          const Icon = achievement.icon;
          return (
            <div
              key={achievement.id}
              className={`bg-white rounded-2xl p-6 shadow-lg transition-all duration-300 ${
                achievement.earned 
                  ? 'border-2 border-blue-200 shadow-xl' 
                  : 'border border-gray-200 opacity-75'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-xl ${
                  achievement.earned ? 'bg-blue-100' : 'bg-gray-100'
                }`}>
                  <Icon className={`w-8 h-8 ${getIconColor(achievement.rarity, achievement.earned)}`} />
                </div>
                
                <div className={`px-3 py-1 rounded-full text-xs font-medium border ${getRarityColor(achievement.rarity)}`}>
                  {achievement.rarity.charAt(0).toUpperCase() + achievement.rarity.slice(1)}
                </div>
              </div>

              <h3 className={`text-xl font-bold mb-2 ${
                achievement.earned ? 'text-gray-900' : 'text-gray-500'
              }`}>
                {achievement.title}
              </h3>
              
              <p className={`text-sm mb-4 ${
                achievement.earned ? 'text-gray-600' : 'text-gray-400'
              }`}>
                {achievement.description}
              </p>

              <div className="flex items-center justify-between">
                <div className={`text-sm font-medium ${
                  achievement.earned ? 'text-blue-600' : 'text-gray-400'
                }`}>
                  {achievement.points} points
                </div>
                
                {achievement.earned && (
                  <div className="text-green-600 text-sm font-medium">
                    ✓ Earned
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Progress Section */}
      <div className="mt-12 bg-gradient-to-r from-gray-50 to-blue-50 rounded-2xl p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Progress</h2>
        
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-700 font-medium">Overall Completion</span>
            <span className="text-gray-700 font-medium">{earnedCount}/{achievements.length}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-blue-600 h-3 rounded-full transition-all duration-500"
              style={{ width: `${(earnedCount / achievements.length) * 100}%` }}
            ></div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Next Achievement</h3>
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              {achievements.find(a => !a.earned) ? (
                <>
                  <div className="font-medium text-gray-900">
                    {achievements.find(a => !a.earned)?.title}
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    {achievements.find(a => !a.earned)?.description}
                  </div>
                </>
              ) : (
                <div className="text-green-600 font-medium">All achievements unlocked! 🎉</div>
              )}
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Keep Learning</h3>
            <div className="space-y-2">
              <button
                onClick={() => onNavigate('lessons')}
                className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Continue Lessons
              </button>
              <button
                onClick={() => onNavigate('practice')}
                className="w-full px-4 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium"
              >
                Practice Mode
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AchievementsPage;