import React, { useState } from 'react';
import { ArrowLeft, BookOpen } from 'lucide-react';
import LessonCard from './LessonCard';
import FreeAbacus from './FreeAbacus';

interface LessonsPageProps {
  onNavigate: (tab: string) => void;
}

const LessonsPage: React.FC<LessonsPageProps> = ({ onNavigate }) => {
  const [selectedLesson, setSelectedLesson] = useState<number | null>(null);

  const lessons = [
    {
      id: 1,
      title: 'Introduction to the Advanced Abacus',
      description: 'Learn the structure and components of the 13-rod abacus system',
      duration: '15 min',
      difficulty: 'Beginner' as const,
      content: {
        title: 'Understanding Your Advanced Abacus',
        sections: [
          {
            heading: 'The 13-Rod System',
            content: 'Our advanced abacus features 13 rods covering place values from ten millions (10,000,000) down to millionths (0.000001). Each rod is color-coded for easy identification of place values.'
          },
          {
            heading: 'Heaven and Earth Sections',
            content: 'Each rod has two sections: Heaven (top) with one bead worth 5 units, and Earth (bottom) with four beads worth 1 unit each. This allows you to represent any digit from 0-9 on each rod.'
          },
          {
            heading: 'Reading Large Numbers and Decimals',
            content: 'The abacus can handle both whole numbers and decimals. The decimal point is implied between the ones and tenths columns. Practice with the interactive abacus below to get familiar with the layout.'
          }
        ]
      }
    },
    {
      id: 2,
      title: 'Basic Number Representation',
      description: 'Master representing numbers 1-9 on individual rods',
      duration: '20 min',
      difficulty: 'Beginner' as const,
      content: {
        title: 'Representing Numbers 1-9',
        sections: [
          {
            heading: 'Numbers 1-4',
            content: 'For numbers 1-4, push up the corresponding number of earth beads from the bottom. The heaven bead stays in the up position. Each earth bead represents 1 unit.'
          },
          {
            heading: 'Number 5',
            content: 'For the number 5, push down the heaven bead only. All earth beads should remain in the down position. The heaven bead represents exactly 5 units.'
          },
          {
            heading: 'Numbers 6-9',
            content: 'For numbers 6-9, push down the heaven bead (worth 5) and push up the required number of earth beads. For example: 7 = heaven bead down + 2 earth beads up (5 + 2 = 7).'
          }
        ]
      }
    },
    {
      id: 3,
      title: 'Working with Place Values',
      description: 'Learn to use multiple rods for large numbers and decimals',
      duration: '25 min',
      difficulty: 'Intermediate' as const,
      content: {
        title: 'Understanding Place Values',
        sections: [
          {
            heading: 'Whole Number Place Values',
            content: 'From left to right: Ten Millions, Millions, Hundred Thousands, Ten Thousands, Thousands, Hundreds, Tens, and Ones. Each position represents a power of 10.'
          },
          {
            heading: 'Decimal Place Values',
            content: 'To the right of ones: Tenths (0.1), Hundredths (0.01), Thousandths (0.001), Ten Thousandths (0.0001), Hundred Thousandths (0.00001), and Millionths (0.000001).'
          },
          {
            heading: 'Building Complex Numbers',
            content: 'To represent 1,234.567, set: 1 in thousands, 2 in hundreds, 3 in tens, 4 in ones, 5 in tenths, 6 in hundredths, and 7 in thousandths. The color coding helps identify each position.'
          }
        ]
      }
    },
    {
      id: 4,
      title: 'Traditional vs Free Mode',
      description: 'Understand the difference between traditional abacus rules and free mode',
      duration: '20 min',
      difficulty: 'Intermediate' as const,
      content: {
        title: 'Abacus Operating Modes',
        sections: [
          {
            heading: 'Traditional Mode',
            content: 'In traditional mode, earth beads move together as a group. When you click a bead, all beads below it move up (become active) or all beads above it move down (become inactive). This follows classical abacus rules.'
          },
          {
            heading: 'Free Mode',
            content: 'Free mode allows independent control of each bead. You can toggle individual beads on or off without affecting others. This is useful for advanced practice and creative exploration.'
          },
          {
            heading: 'When to Use Each Mode',
            content: 'Use traditional mode for learning proper abacus techniques and standard calculations. Use free mode for advanced practice, experimentation, or when you need precise control over individual beads.'
          }
        ]
      }
    },
    {
      id: 5,
      title: 'Simple Addition and Subtraction',
      description: 'Perform basic arithmetic operations on the advanced abacus',
      duration: '30 min',
      difficulty: 'Intermediate' as const,
      content: {
        title: 'Basic Arithmetic Operations',
        sections: [
          {
            heading: 'Addition Process',
            content: 'Start with the first number set on the abacus. To add another number, work from right to left (smallest to largest place value). Add each digit to the corresponding rod, carrying over when a rod exceeds 9.'
          },
          {
            heading: 'Handling Carries',
            content: 'When adding results in more than 9 on any rod, reset that rod to show the remainder and add 1 to the next higher place value. For example, 7 + 5 = 12, so show 2 and carry 1 to the next rod.'
          },
          {
            heading: 'Subtraction Technique',
            content: 'For subtraction, start with the larger number set on the abacus. Remove the value of the smaller number, borrowing from higher place values when necessary. Practice with simple problems first.'
          }
        ]
      }
    },
    {
      id: 6,
      title: 'Decimal Calculations',
      description: 'Master working with decimal numbers and precise calculations',
      duration: '35 min',
      difficulty: 'Advanced' as const,
      content: {
        title: 'Advanced Decimal Operations',
        sections: [
          {
            heading: 'Decimal Alignment',
            content: 'When working with decimals, ensure proper alignment of decimal places. The decimal point is implied between the ones and tenths columns. Always align decimal places when adding or subtracting.'
          },
          {
            heading: 'Precision and Rounding',
            content: 'The 13-rod system allows precision to millionths (6 decimal places). When calculations result in more precision than available, round appropriately. Practice with various decimal combinations.'
          },
          {
            heading: 'Real-World Applications',
            content: 'Use decimal calculations for money (cents), measurements (meters, grams), and scientific notation. The visual nature of the abacus helps understand decimal relationships and place value concepts.'
          }
        ]
      }
    }
  ];

  if (selectedLesson !== null) {
    const lesson = lessons.find(l => l.id === selectedLesson);
    if (!lesson) return null;

    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={() => setSelectedLesson(null)}
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Lessons</span>
            </button>
            
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-700">
                Advanced 13-Rod Abacus
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-6">{lesson.content.title}</h1>
              
              {lesson.content.sections.map((section, index) => (
                <div key={index} className="mb-8">
                  <h2 className="text-xl font-semibold text-gray-800 mb-3">{section.heading}</h2>
                  <p className="text-gray-600 leading-relaxed">{section.content}</p>
                </div>
              ))}

              <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-2">💡 Pro Tip</h3>
                <p className="text-blue-800 text-sm">
                  The advanced 13-rod abacus offers incredible precision and range. Take time to explore both traditional and free modes to fully understand the capabilities. The color-coded rods make it easy to identify place values at a glance!
                </p>
              </div>
            </div>

            <div className="xl:sticky xl:top-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Practice Area</h3>
              
              <FreeAbacus showValue={true} className="mb-6" />
              
              <div className="mt-6 flex space-x-3">
                <button
                  onClick={() => onNavigate('practice')}
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
                >
                  Practice Mode
                </button>
                <button
                  onClick={() => {
                    const nextLesson = lessons.find(l => l.id === selectedLesson + 1);
                    if (nextLesson) {
                      setSelectedLesson(nextLesson.id);
                    }
                  }}
                  className="flex-1 px-4 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-semibold"
                  disabled={selectedLesson === lessons.length}
                >
                  Next Lesson
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Abacus Lessons</h1>
        <p className="text-xl text-gray-600">
          Master the advanced 13-rod abacus system step by step with our comprehensive lesson series
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {lessons.map((lesson) => (
          <LessonCard
            key={lesson.id}
            title={lesson.title}
            description={lesson.description}
            duration={lesson.duration}
            difficulty={lesson.difficulty}
            onClick={() => setSelectedLesson(lesson.id)}
          />
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Advanced Learning Path</h2>
        <p className="text-gray-600 mb-6">
          Our curriculum is designed around the powerful 13-rod abacus system, offering precision from millions to millionths. 
          Each lesson builds upon the previous one, starting with basic concepts and advancing to complex decimal calculations.
        </p>
        <div className="flex flex-wrap gap-2">
          {lessons.map((lesson, index) => (
            <div
              key={lesson.id}
              className="flex items-center space-x-2 px-4 py-2 rounded-lg shadow-sm bg-white border border-purple-200"
            >
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold text-white bg-purple-600">
                {index + 1}
              </div>
              <span className="text-sm font-medium text-gray-700">{lesson.title}</span>
              <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">13-Rod</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LessonsPage;