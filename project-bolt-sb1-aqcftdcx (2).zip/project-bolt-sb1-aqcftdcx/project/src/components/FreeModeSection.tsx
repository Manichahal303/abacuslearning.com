import React, { useState } from 'react';
import { ArrowLeft, Zap, Settings, Calculator } from 'lucide-react';
import FreeAbacus from './FreeAbacus';

interface FreeModeSectionProps {
  onNavigate: (tab: string) => void;
}

const FreeModeSection: React.FC<FreeModeSectionProps> = ({ onNavigate }) => {
  const [practiceMode, setPracticeMode] = useState<'free' | 'target' | null>(null);
  const [targetValue, setTargetValue] = useState<number | undefined>(undefined);

  const generateRandomTarget = () => {
    // Generate a random number with decimals
    const hasDecimals = Math.random() < 0.5;
    if (hasDecimals) {
      const wholePart = Math.floor(Math.random() * 10000);
      const decimalPart = Math.floor(Math.random() * 1000) / 1000;
      return Math.round((wholePart + decimalPart) * 1000) / 1000;
    } else {
      return Math.floor(Math.random() * 100000) + 1;
    }
  };

  const startTargetPractice = () => {
    setTargetValue(generateRandomTarget());
    setPracticeMode('target');
  };

  const newTarget = () => {
    setTargetValue(generateRandomTarget());
  };

  if (practiceMode) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-6">
          <button
            onClick={() => setPracticeMode(null)}
            className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Free Mode Options</span>
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-purple-900 mb-4">
              {practiceMode === 'free' ? 'Free Practice Mode' : 'Target Practice Mode'}
            </h2>
            <p className="text-xl text-gray-600">
              {practiceMode === 'free' 
                ? 'Experiment freely with the advanced abacus - no rules, just exploration!'
                : 'Set the abacus to match the target value using any method you like!'
              }
            </p>
          </div>

          {practiceMode === 'target' && (
            <div className="flex justify-center mb-6">
              <button
                onClick={newTarget}
                className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-semibold"
              >
                New Target Number
              </button>
            </div>
          )}

          <FreeAbacus 
            showValue={true}
            targetValue={practiceMode === 'target' ? targetValue : undefined}
            className="mb-8"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-purple-900 mb-4">Free Mode Abacus</h1>
        <p className="text-xl text-gray-600 max-w-4xl mx-auto">
          Experience the ultimate flexibility with our advanced free mode abacus. Toggle between traditional 
          abacus behavior and complete freedom to manipulate individual beads. Perfect for advanced learners 
          and creative exploration!
        </p>
      </div>

      {/* Feature Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="bg-gradient-to-br from-purple-100 to-blue-100 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-purple-900 mb-4">Free Mode Toggle</h3>
          <p className="text-gray-600">
            Switch between traditional abacus rules and complete freedom to move individual beads independently.
          </p>
        </div>

        <div className="bg-gradient-to-br from-blue-100 to-cyan-100 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
            <Calculator className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-blue-900 mb-4">13-Rod Precision</h3>
          <p className="text-gray-600">
            Work with millions down to millionths with our comprehensive 13-rod abacus system.
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-100 to-teal-100 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
            <Settings className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-green-900 mb-4">Advanced Features</h3>
          <p className="text-gray-600">
            Color-coded place values, responsive design, and intuitive touch controls for the best experience.
          </p>
        </div>
      </div>

      {/* Mode Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div
          onClick={() => setPracticeMode('free')}
          className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border-2 border-purple-200"
        >
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
              <Zap className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-purple-900 mb-4">Free Practice</h3>
            <p className="text-gray-600 mb-6">
              Experiment with the abacus without any constraints. Perfect for creative exploration and 
              understanding how individual beads contribute to the total value.
            </p>
            <div className="bg-purple-100 text-purple-800 py-3 px-6 rounded-lg font-semibold">
              Start Free Practice
            </div>
          </div>
        </div>

        <div
          onClick={startTargetPractice}
          className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border-2 border-blue-200"
        >
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
              <Calculator className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-blue-900 mb-4">Target Practice</h3>
            <p className="text-gray-600 mb-6">
              Challenge yourself to set specific target values using the free mode abacus. 
              Great for testing your understanding and building confidence.
            </p>
            <div className="bg-blue-100 text-blue-800 py-3 px-6 rounded-lg font-semibold">
              Start Target Practice
            </div>
          </div>
        </div>
      </div>

      {/* Demo Section */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl p-8">
        <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">Try the Free Mode Abacus</h2>
        
        <FreeAbacus showValue={true} className="mb-8" />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-3">🎯 Traditional Mode</h3>
            <p className="text-gray-600 text-sm">
              When free mode is OFF, beads follow traditional abacus rules - lower beads move together as a group.
            </p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-3">🔓 Free Mode</h3>
            <p className="text-gray-600 text-sm">
              When free mode is ON, each bead can be moved independently, allowing for creative configurations.
            </p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-3">🌈 Color Coding</h3>
            <p className="text-gray-600 text-sm">
              Each place value has its own color to help you quickly identify millions, thousands, ones, and decimals.
            </p>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-3">📱 Mobile Ready</h3>
            <p className="text-gray-600 text-sm">
              Fully responsive design works perfectly on all devices. Rotate to landscape for the best mobile experience.
            </p>
          </div>
        </div>

        <div className="text-center mt-8">
          <button
            onClick={() => onNavigate('lessons')}
            className="px-8 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-semibold mr-4"
          >
            Learn the Basics First
          </button>
          <button
            onClick={() => onNavigate('practice')}
            className="px-8 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-semibold"
          >
            Try Regular Practice
          </button>
        </div>
      </div>
    </div>
  );
};

export default FreeModeSection;