import React, { useState, useEffect, useRef } from 'react';
import { RotateCcw } from 'lucide-react';

interface FreeAbacusProps {
  showValue?: boolean;
  targetValue?: number;
  onValueChange?: (value: number) => void;
  className?: string;
}

const FreeAbacus: React.FC<FreeAbacusProps> = ({ 
  showValue = true, 
  targetValue,
  onValueChange,
  className = ""
}) => {
  const abacusRef = useRef<HTMLDivElement>(null);
  const [freeMode, setFreeMode] = useState(false);
  const [currentValue, setCurrentValue] = useState(0);
  const placeValues = [1000000, 100000, 10000, 1000, 100, 10, 1, 0.1, 0.01, 0.001, 0.0001, 0.00001, 0.000001];

  const createAbacus = () => {
    if (!abacusRef.current) return;
    
    const upperSection = abacusRef.current.querySelector('#upperSection');
    const lowerSection = abacusRef.current.querySelector('#lowerSection');
    
    if (!upperSection || !lowerSection) return;
    
    // Clear existing content
    upperSection.innerHTML = '';
    lowerSection.innerHTML = '';
    
    // Calculate responsive spacing
    const frameWidth = abacusRef.current.querySelector('.abacus-frame')?.clientWidth || 800;
    const rodSpacing = (frameWidth - 50) / 12; // 13 rods = 12 spaces
    
    for (let i = 0; i < 13; i++) {
      const rodX = 25 + (i * rodSpacing);
      
      // Create upper rod
      const upperRod = document.createElement('div');
      upperRod.className = 'rod upper-rod';
      upperRod.style.left = rodX + 'px';
      upperSection.appendChild(upperRod);
      
      // Create lower rod
      const lowerRod = document.createElement('div');
      lowerRod.className = 'rod lower-rod';
      lowerRod.style.left = rodX + 'px';
      lowerSection.appendChild(lowerRod);
      
      // Create upper bead (1 bead = 5 units)
      const upperBead = document.createElement('div');
      upperBead.className = 'bead upper-bead inactive';
      upperBead.style.left = (rodX - 18) + 'px';
      upperBead.style.top = '5px';
      upperBead.dataset.rod = i.toString();
      upperBead.dataset.type = 'upper';
      upperBead.addEventListener('click', () => toggleBead(upperBead));
      upperBead.addEventListener('touchstart', (e) => {
        e.preventDefault();
        toggleBead(upperBead);
      });
      upperSection.appendChild(upperBead);
      
      // Create lower beads (4 beads = 1 unit each)
      for (let j = 0; j < 4; j++) {
        const lowerBead = document.createElement('div');
        lowerBead.className = 'bead lower-bead';
        lowerBead.style.left = (rodX - 15) + 'px';
        lowerBead.style.top = (120 - (j * 30)) + 'px';
        lowerBead.dataset.rod = i.toString();
        lowerBead.dataset.type = 'lower';
        lowerBead.dataset.index = j.toString();
        lowerBead.addEventListener('click', () => toggleBead(lowerBead));
        lowerBead.addEventListener('touchstart', (e) => {
          e.preventDefault();
          toggleBead(lowerBead);
        });
        lowerSection.appendChild(lowerBead);
      }
    }
  };

  const toggleBead = (bead: HTMLElement) => {
    const rod = parseInt(bead.dataset.rod || '0');
    const type = bead.dataset.type;
    
    if (type === 'upper') {
      if (bead.classList.contains('active')) {
        bead.classList.remove('active');
        bead.classList.add('inactive');
      } else {
        bead.classList.remove('inactive');
        bead.classList.add('active');
      }
    } else {
      // Lower bead logic
      if (!freeMode) {
        const beadIndex = parseInt(bead.dataset.index || '0');
        const rodBeads = abacusRef.current?.querySelectorAll(`[data-rod="${rod}"][data-type="lower"]`);
        
        if (rodBeads) {
          if (bead.classList.contains('active')) {
            // Deactivate this bead and all beads above it
            for (let i = 0; i <= beadIndex; i++) {
              rodBeads[i]?.classList.remove('active');
            }
          } else {
            // Activate this bead and all beads below it
            for (let i = beadIndex; i < 4; i++) {
              rodBeads[i]?.classList.add('active');
            }
          }
        }
      } else {
        // Free mode - just toggle the individual bead
        bead.classList.toggle('active');
      }
    }
    
    updateValue();
  };

  const updateValue = () => {
    if (!abacusRef.current) return;
    
    let totalValue = 0;
    
    // Calculate value from all beads
    for (let i = 0; i < 13; i++) {
      const placeValue = placeValues[i];
      
      // Upper bead (worth 5 units)
      const upperBead = abacusRef.current.querySelector(`[data-rod="${i}"][data-type="upper"]`);
      if (upperBead && upperBead.classList.contains('active')) {
        totalValue += placeValue * 5;
      }
      
      // Lower beads (worth 1 unit each)
      const lowerBeads = abacusRef.current.querySelectorAll(`[data-rod="${i}"][data-type="lower"]`);
      lowerBeads.forEach(bead => {
        if (bead.classList.contains('active')) {
          totalValue += placeValue;
        }
      });
    }
    
    setCurrentValue(totalValue);
    if (onValueChange) {
      onValueChange(totalValue);
    }
  };

  const resetAbacus = () => {
    if (!abacusRef.current) return;
    
    // Reset all beads to inactive state
    const allBeads = abacusRef.current.querySelectorAll('.bead');
    allBeads.forEach(bead => {
      bead.classList.remove('active');
      if (bead.classList.contains('upper-bead')) {
        bead.classList.add('inactive');
      }
    });
    updateValue();
  };

  const toggleFreeMode = () => {
    setFreeMode(prev => {
      const newFreeMode = !prev;
      
      if (!newFreeMode && abacusRef.current) {
        // When exiting free mode, fix the lower beads to follow abacus rules
        for (let rod = 0; rod < 13; rod++) {
          const lowerBeads = abacusRef.current.querySelectorAll(`[data-rod="${rod}"][data-type="lower"]`);
          let activeCount = 0;
          lowerBeads.forEach(bead => {
            if (bead.classList.contains('active')) activeCount++;
          });
          
          // Reset and set correct pattern
          lowerBeads.forEach((bead, index) => {
            bead.classList.remove('active');
            if (index >= (4 - activeCount)) {
              bead.classList.add('active');
            }
          });
        }
        updateValue();
      }
      
      return newFreeMode;
    });
  };

  const formatValue = (value: number) => {
    if (value >= 1) {
      return value.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 6
      });
    } else {
      return value.toFixed(6).replace(/\.?0+$/, '');
    }
  };

  const handleOrientationChange = () => {
    setTimeout(() => {
      createAbacus();
      updateValue();
    }, 100);
  };

  useEffect(() => {
    createAbacus();
    updateValue();
    
    window.addEventListener('orientationchange', handleOrientationChange);
    window.addEventListener('resize', handleOrientationChange);
    
    return () => {
      window.removeEventListener('orientationchange', handleOrientationChange);
      window.removeEventListener('resize', handleOrientationChange);
    };
  }, []);

  const isCorrect = targetValue !== undefined && Math.abs(currentValue - targetValue) < 0.000001;

  return (
    <div className={`${className}`} ref={abacusRef}>
      <style jsx>{`
        .abacus-container {
          background: #8B4A9C;
          padding: 15px;
          border-radius: 15px;
          box-shadow: 0 10px 30px rgba(0,0,0,0.3);
          margin: 10px;
          max-width: 100vw;
          overflow-x: auto;
        }

        .abacus-frame {
          background: white;
          border-radius: 10px;
          padding: 10px;
          width: 100%;
          min-width: 800px;
          height: 300px;
          position: relative;
          overflow: visible;
        }

        .value-display {
          position: absolute;
          top: -5px;
          left: 50%;
          transform: translateX(-50%);
          background: #8B4A9C;
          color: white;
          padding: 8px 20px;
          border-radius: 8px;
          font-weight: bold;
          font-size: 16px;
          z-index: 10;
          white-space: nowrap;
        }

        .place-values {
          position: absolute;
          top: 25px;
          left: 0;
          right: 0;
          display: flex;
          justify-content: space-between;
          padding: 0 25px;
          font-size: 9px;
          font-weight: bold;
          color: #666;
          z-index: 5;
        }

        .place-value {
          width: 50px;
          text-align: center;
          line-height: 1.2;
        }

        .color-bar {
          position: absolute;
          top: 45px;
          left: 25px;
          right: 25px;
          height: 15px;
          display: flex;
          border-radius: 8px;
          overflow: hidden;
          z-index: 4;
        }

        .color-segment {
          flex: 1;
          height: 100%;
        }

        .color-segment:nth-child(1) { background: #4A148C; }
        .color-segment:nth-child(2) { background: #6A1B9A; }
        .color-segment:nth-child(3) { background: #00BCD4; }
        .color-segment:nth-child(4) { background: #00ACC1; }
        .color-segment:nth-child(5) { background: #4CAF50; }
        .color-segment:nth-child(6) { background: #8BC34A; }
        .color-segment:nth-child(7) { background: #CDDC39; }
        .color-segment:nth-child(8) { background: #FFC107; }
        .color-segment:nth-child(9) { background: #FF9800; }
        .color-segment:nth-child(10) { background: #FF5722; }
        .color-segment:nth-child(11) { background: #F44336; }
        .color-segment:nth-child(12) { background: #E91E63; }
        .color-segment:nth-child(13) { background: #9C27B0; }

        .upper-section {
          height: 70px;
          position: relative;
          border-bottom: 3px solid #8B4A9C;
          margin-top: 60px;
        }

        .lower-section {
          height: 160px;
          position: relative;
          margin-top: 10px;
        }

        .rod {
          position: absolute;
          width: 3px;
          height: 100%;
          background: #666;
          border-radius: 2px;
        }

        .upper-rod {
          height: 60px;
          top: 5px;
        }

        .lower-rod {
          height: 150px;
          top: 5px;
        }

        .bead {
          width: 35px;
          height: 35px;
          border-radius: 50%;
          position: absolute;
          cursor: pointer;
          transition: all 0.3s ease;
          border: 2px solid #333;
          left: 50%;
          transform: translateX(-50%);
          background: radial-gradient(circle at 30% 30%, #808080, #404040);
          box-shadow: 0 4px 8px rgba(0,0,0,0.3);
          touch-action: manipulation;
        }

        .bead:hover {
          transform: translateX(-50%) scale(1.1);
          box-shadow: 0 6px 12px rgba(0,0,0,0.4);
        }

        .bead:active {
          transform: translateX(-50%) scale(0.95);
        }

        .bead.active {
          background: radial-gradient(circle at 30% 30%, #66BB6A, #2E7D32);
          box-shadow: 0 4px 8px rgba(76, 175, 80, 0.4);
        }

        .upper-bead {
          width: 40px;
          height: 40px;
        }

        .upper-bead.active {
          top: 30px !important;
        }

        .upper-bead.inactive {
          top: 5px !important;
        }

        .lower-bead.active {
          top: 5px !important;
        }

        .free-mode {
          position: absolute;
          bottom: 10px;
          left: 20px;
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 12px;
          color: #666;
        }

        .toggle {
          width: 40px;
          height: 20px;
          background: #ccc;
          border-radius: 20px;
          position: relative;
          cursor: pointer;
          transition: background 0.3s;
          touch-action: manipulation;
        }

        .toggle.active {
          background: #8B4A9C;
        }

        .toggle-slider {
          width: 16px;
          height: 16px;
          background: white;
          border-radius: 50%;
          position: absolute;
          top: 2px;
          left: 2px;
          transition: left 0.3s;
        }

        .toggle.active .toggle-slider {
          left: 22px;
        }

        @media screen and (max-width: 768px) {
          .abacus-frame {
            min-width: 100vw;
            width: calc(100vw - 20px);
            padding: 5px;
          }
          
          .place-values {
            font-size: 8px;
            padding: 0 15px;
          }
          
          .place-value {
            width: 45px;
          }
          
          .color-bar {
            left: 15px;
            right: 15px;
          }
          
          .bead {
            width: 30px;
            height: 30px;
          }
          
          .upper-bead {
            width: 35px;
            height: 35px;
          }
        }

        @media screen and (max-width: 480px) {
          .place-values {
            font-size: 7px;
          }
          
          .place-value {
            width: 35px;
          }
          
          .bead {
            width: 25px;
            height: 25px;
          }
          
          .upper-bead {
            width: 30px;
            height: 30px;
          }
          
          .value-display {
            font-size: 14px;
            padding: 6px 15px;
          }
        }
      `}</style>

      <div className="abacus-container">
        <div className="abacus-frame">
          {showValue && (
            <div className={`value-display ${
              isCorrect ? 'bg-green-600' : 
              targetValue !== undefined ? 'bg-red-600' : ''
            }`}>
              {formatValue(currentValue)}
              {targetValue !== undefined && isCorrect && ' ✓'}
            </div>
          )}
          
          <div className="place-values">
            <div className="place-value">Ten Lakhs<br/>1000000</div>
            <div className="place-value">Lakhs<br/>100000</div>
            <div className="place-value">Ten Thousands<br/>10000</div>
            <div className="place-value">Thousands<br/>1000</div>
            <div className="place-value">Hundreds<br/>100</div>
            <div className="place-value">Tens<br/>10</div>
            <div className="place-value">Ones<br/>1</div>
            <div className="place-value">Tenths<br/>0.1</div>
            <div className="place-value">Hundredths<br/>0.01</div>
            <div className="place-value">Thousandths<br/>0.001</div>
            <div className="place-value">Ten Thousandths<br/>0.0001</div>
            <div className="place-value">Hundred Thousandths<br/>0.00001</div>
            <div className="place-value">Millionths<br/>0.000001</div>
          </div>

          <div className="color-bar">
            {Array.from({ length: 13 }, (_, i) => (
              <div key={i} className="color-segment"></div>
            ))}
          </div>

          <div className="upper-section" id="upperSection">
            {/* Upper rods and beads will be generated by JavaScript */}
          </div>

          <div className="lower-section" id="lowerSection">
            {/* Lower rods and beads will be generated by JavaScript */}
          </div>

          <div className="free-mode">
            <span>Free Mode?</span>
            <div 
              className={`toggle ${freeMode ? 'active' : ''}`}
              onClick={toggleFreeMode}
            >
              <div className="toggle-slider"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center items-center gap-4 mt-4">
        <button
          onClick={resetAbacus}
          className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
        >
          <RotateCcw size={16} />
          <span>Reset</span>
        </button>
        <span className="text-sm text-gray-600">
          Tap beads to move • Value: <span className="font-bold">{formatValue(currentValue)}</span>
        </span>
      </div>

      {targetValue !== undefined && (
        <div className="text-center mt-4">
          <div className="text-lg text-gray-600">
            Target: {formatValue(targetValue)}
            {isCorrect && <span className="text-green-600 ml-2">✓ Correct!</span>}
          </div>
        </div>
      )}

      <div className="mt-6 bg-white rounded-lg p-4 text-sm shadow-lg">
        <h4 className="font-semibold text-purple-900 mb-2">How to Use the Free Mode Abacus</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-600">
          <div>
            <strong>Upper Section:</strong> Each round bead represents 5 units. Tap to move up (active) or down (inactive).
          </div>
          <div>
            <strong>Lower Section:</strong> Each round bead represents 1 unit. {freeMode ? 'In free mode, toggle individual beads independently.' : 'Beads move together following traditional abacus rules.'}
          </div>
          <div>
            <strong>Free Mode Toggle:</strong> Switch between traditional abacus behavior and free individual bead control.
          </div>
          <div>
            <strong>Mobile Friendly:</strong> Rotate your device to landscape mode for the best experience on mobile.
          </div>
        </div>
      </div>
    </div>
  );
};

export default FreeAbacus;