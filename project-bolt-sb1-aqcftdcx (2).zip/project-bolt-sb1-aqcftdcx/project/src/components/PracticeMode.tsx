import React, { useState, useEffect } from 'react';
import { RefreshCw, Trophy, Target, Clock, Star, TrendingUp, Award, CheckCircle, XCircle } from 'lucide-react';
import FreeAbacus from './FreeAbacus';

interface PracticeModeProps {
  difficulty: 'easy' | 'medium' | 'hard' | 'advanced';
}

interface ProblemHistory {
  problem: number;
  userAnswer: number;
  correct: boolean;
  timeSpent: number;
}

const PracticeMode: React.FC<PracticeModeProps> = ({ difficulty }) => {
  const [currentProblem, setCurrentProblem] = useState<number>(0);
  const [userAnswer, setUserAnswer] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [attempts, setAttempts] = useState<number>(0);
  const [showResult, setShowResult] = useState<boolean>(false);
  const [streak, setStreak] = useState<number>(0);
  const [bestStreak, setBestStreak] = useState<number>(0);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [sessionTime, setSessionTime] = useState<number>(0);
  const [problemHistory, setProblemHistory] = useState<ProblemHistory[]>([]);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [problemStartTime, setProblemStartTime] = useState<number>(Date.now());

  const generateProblem = () => {
    let max = 50;
    let min = 1;
    let useDecimals = false;
    
    switch (difficulty) {
      case 'medium':
        max = 500;
        break;
      case 'hard':
        max = 9999;
        break;
      case 'advanced':
        max = 999999;
        min = 0.001;
        useDecimals = true;
        break;
    }
    
    if (useDecimals) {
      // Generate either a whole number or a decimal
      if (Math.random() < 0.5) {
        // Generate decimal number
        const wholePart = Math.floor(Math.random() * 1000);
        const decimalPart = Math.floor(Math.random() * 1000) / 1000;
        return Math.round((wholePart + decimalPart) * 1000) / 1000;
      } else {
        // Generate whole number
        return Math.floor(Math.random() * max) + 1;
      }
    }
    
    return Math.floor(Math.random() * max) + min;
  };

  const [targetNumber, setTargetNumber] = useState<number>(generateProblem());

  useEffect(() => {
    setTargetNumber(generateProblem());
    setProblemStartTime(Date.now());
  }, [difficulty]);

  useEffect(() => {
    const timer = setInterval(() => {
      setSessionTime(Date.now() - startTime);
    }, 1000);

    return () => clearInterval(timer);
  }, [startTime]);

  const handleSubmit = () => {
    const timeSpent = Date.now() - problemStartTime;
    setAttempts(prev => prev + 1);
    const tolerance = difficulty === 'advanced' ? 0.001 : 0;
    const isCorrect = Math.abs(userAnswer - targetNumber) <= tolerance;
    
    // Add to history
    setProblemHistory(prev => [...prev, {
      problem: targetNumber,
      userAnswer: userAnswer,
      correct: isCorrect,
      timeSpent: timeSpent
    }]);
    
    if (isCorrect) {
      setScore(prev => prev + 1);
      setStreak(prev => {
        const newStreak = prev + 1;
        if (newStreak > bestStreak) {
          setBestStreak(newStreak);
        }
        return newStreak;
      });
      setShowResult(true);
      setTimeout(() => {
        nextProblem();
      }, 2000);
    } else {
      setStreak(0);
      setShowResult(true);
      setTimeout(() => {
        setShowResult(false);
      }, 3000);
    }
  };

  const nextProblem = () => {
    setTargetNumber(generateProblem());
    setUserAnswer(0);
    setShowResult(false);
    setShowHint(false);
    setProblemStartTime(Date.now());
  };

  const resetSession = () => {
    setScore(0);
    setAttempts(0);
    setStreak(0);
    setStartTime(Date.now());
    setSessionTime(0);
    setProblemHistory([]);
    nextProblem();
  };

  const getHint = () => {
    setShowHint(true);
  };

  const accuracy = attempts > 0 ? Math.round((score / attempts) * 100) : 0;
  const averageTime = problemHistory.length > 0 
    ? problemHistory.reduce((sum, p) => sum + p.timeSpent, 0) / problemHistory.length / 1000 
    : 0;

  const formatNumber = (num: number) => {
    if (difficulty === 'advanced') {
      return num.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 6
      });
    }
    return num.toLocaleString();
  };

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return minutes > 0 ? `${minutes}:${remainingSeconds.toString().padStart(2, '0')}` : `${remainingSeconds}s`;
  };

  const getDifficultyInfo = () => {
    switch (difficulty) {
      case 'easy': return { name: 'Easy', color: 'text-green-600', bg: 'bg-green-50', range: '1-50' };
      case 'medium': return { name: 'Medium', color: 'text-yellow-600', bg: 'bg-yellow-50', range: '1-500' };
      case 'hard': return { name: 'Hard', color: 'text-red-600', bg: 'bg-red-50', range: '1-9,999' };
      case 'advanced': return { name: 'Advanced', color: 'text-purple-600', bg: 'bg-purple-50', range: 'Decimals & Large Numbers' };
      default: return { name: 'Easy', color: 'text-green-600', bg: 'bg-green-50', range: '1-50' };
    }
  };

  const difficultyInfo = getDifficultyInfo();

  const getStreakMessage = () => {
    if (streak >= 10) return "🔥 On Fire!";
    if (streak >= 5) return "⚡ Great Streak!";
    if (streak >= 3) return "🎯 Nice Work!";
    return "";
  };

  const getHintText = () => {
    const target = targetNumber;
    if (difficulty === 'advanced') {
      if (target < 1) {
        return `This is a decimal number. Focus on the decimal place values (tenths, hundredths, etc.)`;
      } else if (target > 10000) {
        return `This is a large number. Use the left-side rods for thousands and higher place values.`;
      }
    }
    
    if (target <= 9) {
      return `This is a single digit. Use only the rightmost rod (ones place).`;
    } else if (target <= 99) {
      return `This is a two-digit number. Use the tens and ones rods.`;
    } else if (target <= 999) {
      return `This is a three-digit number. Use hundreds, tens, and ones rods.`;
    }
    
    return `Break down the number by place value. Work from left to right, setting each digit on its corresponding rod.`;
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="bg-white rounded-2xl shadow-xl p-8">
        {/* Header with enhanced stats */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-6">
          <div>
            <div className="flex items-center space-x-3 mb-2">
              <h2 className="text-3xl font-bold text-gray-900">Practice Mode</h2>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${difficultyInfo.bg} ${difficultyInfo.color}`}>
                {difficultyInfo.name}
              </span>
              <span className="px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-700">
                Advanced 13-Rod Abacus
              </span>
            </div>
            <p className="text-gray-600 mb-2">
              Range: <span className="font-semibold">{difficultyInfo.range}</span>
            </p>
            <p className="text-gray-600">
              Set the abacus to show: <span className="font-bold text-3xl text-blue-600">{formatNumber(targetNumber)}</span>
            </p>
            {streak > 0 && (
              <p className="text-orange-600 font-semibold mt-2">
                {getStreakMessage()} Streak: {streak}
              </p>
            )}
          </div>
          
          {/* Enhanced Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-green-50 p-4 rounded-lg text-center min-w-[100px]">
              <Trophy className="w-6 h-6 text-green-600 mx-auto mb-1" />
              <div className="text-2xl font-bold text-green-600">{score}</div>
              <div className="text-sm text-gray-600">Correct</div>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg text-center min-w-[100px]">
              <Target className="w-6 h-6 text-blue-600 mx-auto mb-1" />
              <div className="text-2xl font-bold text-blue-600">{accuracy}%</div>
              <div className="text-sm text-gray-600">Accuracy</div>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg text-center min-w-[100px]">
              <Star className="w-6 h-6 text-orange-600 mx-auto mb-1" />
              <div className="text-2xl font-bold text-orange-600">{bestStreak}</div>
              <div className="text-sm text-gray-600">Best Streak</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg text-center min-w-[100px]">
              <Clock className="w-6 h-6 text-purple-600 mx-auto mb-1" />
              <div className="text-2xl font-bold text-purple-600">{formatTime(sessionTime)}</div>
              <div className="text-sm text-gray-600">Session Time</div>
            </div>
          </div>
        </div>

        {/* Abacus */}
        <div className="mb-8">
          <FreeAbacus
            showValue={true}
            targetValue={targetNumber}
            onValueChange={setUserAnswer}
          />
        </div>

        {/* Result Display */}
        {showResult && (
          <div className={`text-center p-6 rounded-lg mb-6 ${
            Math.abs(userAnswer - targetNumber) <= (difficulty === 'advanced' ? 0.001 : 0)
              ? 'bg-green-100 text-green-800 border-2 border-green-300' 
              : 'bg-red-100 text-red-800 border-2 border-red-300'
          }`}>
            <div className="flex items-center justify-center mb-2">
              {Math.abs(userAnswer - targetNumber) <= (difficulty === 'advanced' ? 0.001 : 0) ? (
                <CheckCircle className="w-8 h-8 mr-2" />
              ) : (
                <XCircle className="w-8 h-8 mr-2" />
              )}
              <span className="text-xl font-bold">
                {Math.abs(userAnswer - targetNumber) <= (difficulty === 'advanced' ? 0.001 : 0)
                  ? '🎉 Excellent! You got it right!' 
                  : 'Not quite right. Keep trying!'
                }
              </span>
            </div>
            {Math.abs(userAnswer - targetNumber) > (difficulty === 'advanced' ? 0.001 : 0) && (
              <p className="text-lg">
                You set <span className="font-bold">{formatNumber(userAnswer)}</span>, but the target was <span className="font-bold">{formatNumber(targetNumber)}</span>.
              </p>
            )}
          </div>
        )}

        {/* Hint Section */}
        {showHint && (
          <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4 mb-6">
            <h4 className="font-semibold text-yellow-800 mb-2">💡 Hint:</h4>
            <p className="text-yellow-700">{getHintText()}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          <button
            onClick={handleSubmit}
            disabled={showResult}
            className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold"
          >
            Check Answer
          </button>
          <button
            onClick={nextProblem}
            className="px-8 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-semibold flex items-center space-x-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>New Problem</span>
          </button>
          <button
            onClick={getHint}
            disabled={showHint}
            className="px-8 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold"
          >
            Get Hint
          </button>
          <button
            onClick={resetSession}
            className="px-8 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-semibold"
          >
            Reset Session
          </button>
        </div>

        {/* Session Statistics */}
        {problemHistory.length > 0 && (
          <div className="bg-gray-50 rounded-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <TrendingUp className="w-6 h-6 mr-2" />
              Session Statistics
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h4 className="font-semibold text-gray-700 mb-2">Performance</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Problems:</span>
                    <span className="font-semibold">{problemHistory.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Correct:</span>
                    <span className="font-semibold text-green-600">{score}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Incorrect:</span>
                    <span className="font-semibold text-red-600">{attempts - score}</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h4 className="font-semibold text-gray-700 mb-2">Timing</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Average Time:</span>
                    <span className="font-semibold">{averageTime.toFixed(1)}s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Session Time:</span>
                    <span className="font-semibold">{formatTime(sessionTime)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Problems/Min:</span>
                    <span className="font-semibold">{((problemHistory.length / (sessionTime / 60000)) || 0).toFixed(1)}</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h4 className="font-semibold text-gray-700 mb-2">Achievements</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Best Streak:</span>
                    <span className="font-semibold text-orange-600">{bestStreak}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Current Streak:</span>
                    <span className="font-semibold">{streak}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Accuracy:</span>
                    <span className={`font-semibold ${accuracy >= 80 ? 'text-green-600' : accuracy >= 60 ? 'text-yellow-600' : 'text-red-600'}`}>
                      {accuracy}%
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Problems */}
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <h4 className="font-semibold text-gray-700 mb-3">Recent Problems</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {problemHistory.slice(-10).reverse().map((problem, index) => (
                  <div key={index} className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded">
                    <span className="font-mono text-sm">
                      {formatNumber(problem.problem)}
                    </span>
                    <div className="flex items-center space-x-3">
                      <span className="text-xs text-gray-500">
                        {(problem.timeSpent / 1000).toFixed(1)}s
                      </span>
                      {problem.correct ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-600" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PracticeMode;