import React from 'react';
import { Calculator, BookOpen, Trophy, Users, Star, TrendingUp, MapPin, Phone, Mail, UserCheck } from 'lucide-react';
import { UserData } from '../App';

interface HomePageProps {
  onNavigate: (tab: string) => void;
  currentUser: UserData | null;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate, currentUser }) => {
  const features = [
    {
      icon: Calculator,
      title: 'Interactive Abacus',
      description: 'Learn with our realistic digital abacus that responds to your touch',
      color: 'bg-blue-500'
    },
    {
      icon: BookOpen,
      title: 'Structured Lessons',
      description: 'Progressive curriculum from basic counting to advanced calculations',
      color: 'bg-green-500'
    },
    {
      icon: Trophy,
      title: 'Practice Modes',
      description: 'Challenge yourself with different difficulty levels and track progress',
      color: 'bg-purple-500'
    },
    {
      icon: TrendingUp,
      title: 'Progress Tracking',
      description: 'Monitor your improvement with detailed analytics and achievements',
      color: 'bg-orange-500'
    }
  ];

  const stats = [
    { label: 'Students Learning', value: '10,000+', icon: Users },
    { label: 'Lessons Completed', value: '50,000+', icon: BookOpen },
    { label: 'Average Rating', value: '4.9/5', icon: Star },
  ];

  const testimonials = [
    {
      name: "Priya Sharma",
      location: "Mumbai, Maharashtra",
      rating: 5,
      comment: "This is absolutely amazing! My daughter learned abacus so quickly with this interactive platform. The 13-rod system is incredibly detailed and the visual feedback is perfect. Thanks to Manjot Singh for creating such a wonderful educational tool!",
      avatar: "PS",
      course: "Completed all 20 levels"
    },
    {
      name: "Rajesh Kumar",
      location: "Delhi, NCR",
      rating: 5,
      comment: "Outstanding work by Manjot Singh! The math practice mode with 4000 problems is exactly what my son needed. The progressive difficulty system is brilliant. Highly recommend this to all parents!",
      avatar: "RK",
      course: "Advanced Level Student"
    },
    {
      name: "Anita Patel",
      location: "Ahmedabad, Gujarat",
      rating: 5,
      comment: "I'm a math teacher and this is the best abacus learning platform I've ever seen. The free mode toggle is genius! My students love practicing here. Grateful to Manjot Singh for this incredible resource.",
      avatar: "AP",
      course: "Teacher - Using for 50+ students"
    },
    {
      name: "Vikram Singh",
      location: "Jaipur, Rajasthan",
      rating: 5,
      comment: "The attention to detail is remarkable! From millions to millionths precision - this covers everything. The color-coded place values make learning so much easier. Excellent work by Manjot Singh!",
      avatar: "VS",
      course: "Completed Beginner to Expert"
    },
    {
      name: "Meera Reddy",
      location: "Hyderabad, Telangana",
      rating: 5,
      comment: "My twins are now abacus champions thanks to this platform! The achievement system keeps them motivated. Manjot Singh has created something truly special here. Thank you so much!",
      avatar: "MR",
      course: "Parent of 2 students"
    },
    {
      name: "Arjun Gupta",
      location: "Pune, Maharashtra",
      rating: 5,
      comment: "As a software engineer, I appreciate the technical excellence of this platform. The responsive design works perfectly on all devices. Kudos to Manjot Singh for building such a robust educational tool!",
      avatar: "AG",
      course: "Adult Learner"
    },
    {
      name: "Kavita Joshi",
      location: "Bangalore, Karnataka",
      rating: 5,
      comment: "The practice modes are incredibly well-designed! 20 levels with increasing difficulty - perfect progression. My daughter's mental math has improved dramatically. Thank you to the talented developer Manjot Singh!",
      avatar: "KJ",
      course: "Level 15 Student"
    },
    {
      name: "Suresh Nair",
      location: "Kochi, Kerala",
      rating: 5,
      comment: "This platform is a game-changer for abacus education! The interactive features and real-time feedback are outstanding. Manjot Singh has created something that will benefit thousands of students.",
      avatar: "SN",
      course: "Abacus Institute Owner"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Welcome Message for Signed In Users */}
        {currentUser && (
          <div className="bg-gradient-to-r from-green-100 to-blue-100 rounded-2xl p-6 mb-8 border-2 border-green-200">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  Welcome back, {currentUser.name}! 👋
                </h2>
                <p className="text-gray-700 mb-2">
                  Roll No: <span className="font-bold text-green-600">{currentUser.rollNo}</span> • 
                  Level {currentUser.level} • 
                  Rank #{currentUser.rank}
                </p>
                <p className="text-gray-600">
                  You've completed {currentUser.completedLessons}/{currentUser.totalLessons} lessons and solved {currentUser.practiceProblems + currentUser.mathProblems} problems!
                </p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-blue-600">{currentUser.points}</div>
                <div className="text-gray-600">Points</div>
              </div>
            </div>
            <div className="mt-4 flex space-x-3">
              <button
                onClick={() => onNavigate('lessons')}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
              >
                Continue Learning
              </button>
              <button
                onClick={() => onNavigate('practice')}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold"
              >
                Practice More
              </button>
            </div>
          </div>
        )}

        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Master the <span className="text-blue-600">Abacus</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Unlock the ancient art of mental calculation with our interactive abacus learning platform. 
            Build mathematical confidence through hands-on practice and structured lessons.
          </p>
          
          {/* Roll No CTA for non-signed in users */}
          {!currentUser && (
            <div className="bg-gradient-to-r from-green-100 to-blue-100 rounded-2xl p-6 mb-8 max-w-2xl mx-auto border-2 border-green-200">
              <div className="flex items-center justify-center mb-4">
                <UserCheck className="w-8 h-8 text-green-600 mr-3" />
                <h3 className="text-2xl font-bold text-gray-900">Get Your Roll Number!</h3>
              </div>
              <p className="text-gray-700 mb-4">
                Join our learning community and get a unique roll number to track your progress, 
                compete with others, and showcase your achievements!
              </p>
              <button
                onClick={() => onNavigate('rollno')}
                className="px-8 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors font-semibold text-lg shadow-lg"
              >
                Get My Roll Number
              </button>
              <div className="mt-3 text-sm text-gray-600">
                Free registration • Instant roll number • Progress tracking • Global rankings
              </div>
            </div>
          )}
          
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => onNavigate('lessons')}
              className="px-8 py-4 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors font-semibold text-lg shadow-lg"
            >
              Start Learning
            </button>
            <button
              onClick={() => onNavigate('practice')}
              className="px-8 py-4 bg-white text-blue-600 border-2 border-blue-600 rounded-xl hover:bg-blue-50 transition-colors font-semibold text-lg"
            >
              Try Practice Mode
            </button>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg text-center">
                <Icon className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Features Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Why Choose AbacusLearn?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                  <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Roll Number System Highlight */}
        {!currentUser && (
          <div className="mb-16 bg-gradient-to-r from-green-50 to-blue-50 rounded-3xl p-12">
            <div className="text-center mb-8">
              <UserCheck className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Student Roll Number System</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Every student gets a unique roll number for personalized learning tracking and transparent progress reports
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-sm text-center">
                <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <UserCheck className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Unique Identity</h3>
                <p className="text-gray-600 text-sm">Get your personal roll number (AB001, AB002, etc.) for easy identification</p>
              </div>
              
              <div className="bg-white rounded-xl p-6 shadow-sm text-center">
                <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Progress Reports</h3>
                <p className="text-gray-600 text-sm">Comprehensive analytics with charts, rankings, and achievement tracking</p>
              </div>
              
              <div className="bg-white rounded-xl p-6 shadow-sm text-center">
                <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Global Rankings</h3>
                <p className="text-gray-600 text-sm">Compete with students worldwide and see your position on leaderboards</p>
              </div>
              
              <div className="bg-white rounded-xl p-6 shadow-sm text-center">
                <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center mb-4 mx-auto">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Public Access</h3>
                <p className="text-gray-600 text-sm">Anyone can view progress reports by entering a roll number</p>
              </div>
            </div>

            <div className="text-center mt-8">
              <button
                onClick={() => onNavigate('rollno')}
                className="px-8 py-4 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors font-semibold text-lg shadow-lg"
              >
                Get Your Roll Number Now
              </button>
            </div>
          </div>
        )}

        {/* User Testimonials Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-4">
            What Our Students Say
          </h2>
          <p className="text-xl text-gray-600 text-center mb-12">
            Join thousands of satisfied learners who have mastered the abacus with our platform
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold mr-4">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.location}</p>
                  </div>
                </div>
                
                <div className="flex items-center mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                <p className="text-gray-700 mb-4 italic">"{testimonial.comment}"</p>
                
                <div className="text-sm text-blue-600 font-medium">
                  {testimonial.course}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-12 text-center text-white mb-16">
          <h2 className="text-3xl font-bold mb-4">Ready to Begin Your Journey?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of students who have already discovered the power of abacus learning
          </p>
          <button
            onClick={() => onNavigate(currentUser ? 'lessons' : 'rollno')}
            className="px-8 py-4 bg-white text-blue-600 rounded-xl hover:bg-gray-100 transition-colors font-semibold text-lg shadow-lg"
          >
            {currentUser ? 'Continue Learning' : 'Get Started Today'}
          </button>
        </div>

        {/* Developer Information Section */}
        <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-3xl p-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">About the Developer</h2>
            <p className="text-xl text-gray-600">
              Created with passion for education and technology
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                      MS
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">Manjot Singh</h3>
                      <p className="text-gray-600">Educational Technology Specialist</p>
                    </div>
                  </div>

                  <p className="text-gray-700 mb-6 leading-relaxed">
                    This comprehensive abacus learning platform was developed with a vision to make 
                    mathematical education more interactive and accessible. The advanced 13-rod system, 
                    progressive learning modules, and innovative practice modes represent countless hours 
                    of development and educational research.
                  </p>

                  <div className="space-y-3">
                    <div className="flex items-center text-gray-700">
                      <MapPin className="w-5 h-5 text-blue-600 mr-3" />
                      <span>
                        <strong>Address:</strong> Village Toderpur, Tehsil Samana, District Patiala, Punjab, India
                      </span>
                    </div>
                    <div className="flex items-center text-gray-700">
                      <Phone className="w-5 h-5 text-green-600 mr-3" />
                      <span>
                        <strong>Mobile:</strong> +91 7837006301
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-xl font-bold text-gray-900 mb-4">Platform Features</h4>
                  <ul className="space-y-3 text-gray-700">
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3"></div>
                      <span>Advanced 13-rod abacus system with precision from millions to millionths</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></div>
                      <span>20-level progressive math practice with 4,000+ problems</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-purple-600 rounded-full mt-2 mr-3"></div>
                      <span>Interactive lessons covering basic to advanced concepts</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></div>
                      <span>Free mode toggle for creative exploration</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-red-600 rounded-full mt-2 mr-3"></div>
                      <span>Comprehensive achievement and progress tracking system</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-teal-600 rounded-full mt-2 mr-3"></div>
                      <span>Fully responsive design optimized for all devices</span>
                    </li>
                    <li className="flex items-start">
                      <div className="w-2 h-2 bg-indigo-600 rounded-full mt-2 mr-3"></div>
                      <span>Student roll number system with progress tracking and global rankings</span>
                    </li>
                  </ul>

                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <h5 className="font-semibold text-blue-900 mb-2">🎯 Mission</h5>
                    <p className="text-blue-800 text-sm">
                      To revolutionize mathematical education by combining traditional abacus wisdom 
                      with modern interactive technology, making learning engaging and effective for 
                      students worldwide.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Thank You Message */}
          <div className="mt-8 text-center">
            <div className="bg-gradient-to-r from-green-100 to-blue-100 rounded-2xl p-6 max-w-2xl mx-auto">
              <h4 className="text-xl font-bold text-gray-900 mb-3">
                🙏 Special Thanks from Our Community
              </h4>
              <p className="text-gray-700 leading-relaxed">
                "We extend our heartfelt gratitude to <strong>Manjot Singh</strong>, the talented developer who created this 
                exceptional educational platform. Your dedication to combining traditional learning 
                methods with cutting-edge technology has made a significant impact on thousands of 
                students. Thank you for making quality education accessible and engaging!"
              </p>
              <div className="mt-4 text-sm text-gray-600">
                - The AbacusLearn Community
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;