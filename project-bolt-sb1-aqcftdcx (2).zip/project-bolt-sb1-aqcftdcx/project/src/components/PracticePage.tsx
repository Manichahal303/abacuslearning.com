import React, { useState } from 'react';
import { Target, Zap, Brain, Calculator, Plus, Minus, X, Divide } from 'lucide-react';
import PracticeMode from './PracticeMode';
import MathPracticeMode from './MathPracticeMode';

interface PracticePageProps {
  onNavigate: (tab: string) => void;
}

const PracticePage: React.FC<PracticePageProps> = ({ onNavigate }) => {
  const [selectedMode, setSelectedMode] = useState<'abacus' | 'math' | null>(null);
  const [selectedDifficulty, setSelectedDifficulty] = useState<'easy' | 'medium' | 'hard' | 'advanced' | null>(null);

  const difficulties = [
    {
      id: 'easy' as const,
      title: 'Easy',
      description: 'Numbers 1-50, perfect for beginners',
      icon: Target,
      color: 'bg-green-500',
      borderColor: 'border-green-500',
      textColor: 'text-green-700'
    },
    {
      id: 'medium' as const,
      title: 'Medium',
      description: 'Numbers 1-500, intermediate challenge',
      icon: Zap,
      color: 'bg-yellow-500',
      borderColor: 'border-yellow-500',
      textColor: 'text-yellow-700'
    },
    {
      id: 'hard' as const,
      title: 'Hard',
      description: 'Numbers 1-9999, for advanced learners',
      icon: Brain,
      color: 'bg-red-500',
      borderColor: 'border-red-500',
      textColor: 'text-red-700'
    },
    {
      id: 'advanced' as const,
      title: 'Advanced',
      description: 'Decimals & large numbers, master level',
      icon: Calculator,
      color: 'bg-purple-500',
      borderColor: 'border-purple-500',
      textColor: 'text-purple-700'
    }
  ];

  if (selectedMode === 'abacus' && selectedDifficulty) {
    return (
      <div>
        <div className="max-w-4xl mx-auto p-6 mb-6">
          <button
            onClick={() => {
              setSelectedDifficulty(null);
              setSelectedMode(null);
            }}
            className="text-blue-600 hover:text-blue-700 transition-colors mb-4"
          >
            ← Back to Practice Options
          </button>
        </div>
        <PracticeMode difficulty={selectedDifficulty} />
      </div>
    );
  }

  if (selectedMode === 'math') {
    return <MathPracticeMode onBack={() => setSelectedMode(null)} />;
  }

  if (selectedMode === 'abacus') {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-6">
          <button
            onClick={() => setSelectedMode(null)}
            className="text-blue-600 hover:text-blue-700 transition-colors mb-4"
          >
            ← Back to Practice Options
          </button>
        </div>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Abacus Practice Mode</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose your difficulty level and start practicing with our advanced 13-rod abacus! 
            Set the abacus to match the target numbers and improve your speed and accuracy.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {difficulties.map((difficulty) => {
            const Icon = difficulty.icon;
            return (
              <div
                key={difficulty.id}
                onClick={() => setSelectedDifficulty(difficulty.id)}
                className={`bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border-2 ${difficulty.borderColor} relative`}
              >
                <div className="absolute top-3 right-3 bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded-full font-medium">
                  13-Rod Abacus
                </div>
                
                <div className={`w-16 h-16 ${difficulty.color} rounded-2xl flex items-center justify-center mb-6 mx-auto`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-2xl font-bold text-gray-900 text-center mb-4">
                  {difficulty.title}
                </h3>
                
                <p className="text-gray-600 text-center mb-6">
                  {difficulty.description}
                </p>
                
                <div className={`text-center py-3 px-6 rounded-lg ${difficulty.textColor} bg-opacity-10 ${difficulty.color.replace('bg-', 'bg-opacity-10 bg-')}`}>
                  <span className="font-semibold">Start Practice</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Abacus Practice Tips</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-gray-900 mb-3">🎯 Start Small</h3>
              <p className="text-gray-600 text-sm">
                Begin with easy mode to build confidence and muscle memory before advancing to harder levels.
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-gray-900 mb-3">⚡ Speed vs Accuracy</h3>
              <p className="text-gray-600 text-sm">
                Focus on accuracy first. Speed will naturally improve as you become more comfortable with the abacus.
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-gray-900 mb-3">🧠 Mental Visualization</h3>
              <p className="text-gray-600 text-sm">
                Try to visualize the abacus in your mind. This will help you perform calculations without the physical tool.
              </p>
            </div>
            
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-gray-900 mb-3">🔢 13-Rod Power</h3>
              <p className="text-gray-600 text-sm">
                Master the advanced 13-rod system for precision from millions down to millionths with color-coded place values.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Practice Mode</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Choose your practice type to improve your mathematical skills and abacus proficiency
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {/* Abacus Practice */}
        <div
          onClick={() => setSelectedMode('abacus')}
          className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border-2 border-purple-200"
        >
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
              <Calculator className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-purple-900 mb-4">Abacus Practice</h3>
            <p className="text-gray-600 mb-6">
              Practice setting numbers on the advanced 13-rod abacus. Perfect for building 
              muscle memory and understanding place values from millions to millionths.
            </p>
            <div className="bg-purple-100 text-purple-800 py-3 px-6 rounded-lg font-semibold">
              Start Abacus Practice
            </div>
            <div className="mt-4 text-sm text-gray-500">
              4 difficulty levels • Visual learning • Real-time feedback
            </div>
          </div>
        </div>

        {/* Math Operations Practice */}
        <div
          onClick={() => setSelectedMode('math')}
          className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border-2 border-blue-200"
        >
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
              <div className="grid grid-cols-2 gap-1">
                <Plus className="w-4 h-4 text-white" />
                <Minus className="w-4 h-4 text-white" />
                <X className="w-4 h-4 text-white" />
                <Divide className="w-4 h-4 text-white" />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-blue-900 mb-4">Math Operations</h3>
            <p className="text-gray-600 mb-6">
              Master addition, subtraction, multiplication, and division with our comprehensive 
              20-level system. Each level contains 200 carefully crafted problems.
            </p>
            <div className="bg-blue-100 text-blue-800 py-3 px-6 rounded-lg font-semibold">
              Start Math Practice
            </div>
            <div className="mt-4 text-sm text-gray-500">
              20 levels • 4 operations • 4,000 total problems
            </div>
          </div>
        </div>
      </div>

      {/* Features Comparison */}
      <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-2xl p-8">
        <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">Practice Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-purple-900 mb-4 flex items-center">
              <Calculator className="w-5 h-5 mr-2" />
              Abacus Practice Features
            </h3>
            <ul className="space-y-2 text-gray-600 text-sm">
              <li>• Interactive 13-rod abacus with color-coded place values</li>
              <li>• Numbers from millions to millionths precision</li>
              <li>• Real-time visual feedback and corrections</li>
              <li>• Progressive difficulty levels</li>
              <li>• Speed and accuracy tracking</li>
              <li>• Mobile-friendly responsive design</li>
            </ul>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-blue-900 mb-4 flex items-center">
              <Target className="w-5 h-5 mr-2" />
              Math Operations Features
            </h3>
            <ul className="space-y-2 text-gray-600 text-sm">
              <li>• 20 progressive difficulty levels</li>
              <li>• 4 operations: +, -, ×, ÷</li>
              <li>• 4 sets of 50 problems per operation</li>
              <li>• Automatic difficulty scaling</li>
              <li>• Comprehensive progress tracking</li>
              <li>• Set completion achievements</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PracticePage;